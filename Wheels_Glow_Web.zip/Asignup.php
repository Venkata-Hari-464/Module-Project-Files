<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Wheels Glow | Signup Form</title> 
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <style>
      body{
        margin-bottom:20px;
        overflow-y: hidden;
      }
      .wrapper form .row input{
  height: 100%;
  width: 100%;
  outline: none;
  padding-left: 50px;
  border-radius: 5px;
  border-width:0px;
  font-size: 16px;
  transition: all 0.3s ease;
}
.wrapper .title {
  padding-top: 45px;
    height: 47px;
    background: transparent;
    border-radius: 5px 5px 0 0;
    color: #fff;
    font-size: 30px;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
}
    </style>
  </head>
  <body style="background-image: url('images/loginbgimg.jpg'); background-size:cover;">
    <div class="container" style="margin-top:105px;">
      <div class="wrapper" style="background-color:#1e6a8f;">
        <div class="title" style="background-color: #1e6a8f;"><span>Signup Form</span></div>
        <form action="Asignuppage.php" method ="post">
          <div class="row">
            <i class="fas fa-user" style="background-color: #1e6a8f;"></i>
            <input type="text" name = "name" placeholder="Enter Your Name" required>
          </div>
          <div class="row">
            <i class="fas fa-user" style="background-color: #1e6a8f;"></i>
            <input type="text" name = "email" placeholder="Enter Your Email" required>
          </div>
          <div class="row">
            <i class="fas fa-user" style="background-color: #1e6a8f;"></i>
            <input type="text" name = "phonenumber" placeholder="Enter Your Phone number" required>
          </div>
          <!-- <div class="row">
            <i class="fas fa-user" style="background-color: #1e6a8f;"></i>
            <input type="text" name = "profession" placeholder="Enter your profession" required>
          </div> -->
          <!-- <div class="row">
            <i class="fas fa-user" style="background-color: #1e6a8f;"></i>
            <input type="text" name = "pincode" placeholder="Enter your pincode" required>
          </div> -->
          <!-- <div class="row">
            <i class="fas fa-user" style="background-color: #1e6a8f;"></i>
            <input type="text" name = "adress" placeholder="Enter your adress" required>
          </div> -->
          <div class="row">
            <i class="fas fa-lock" style="background-color: #1e6a8f;"></i>
            <input type="password"  name ="password" placeholder="Password" required>
          </div>
          
          <div class="row button">
            <input type="submit" value="Signup" style="background-color: #1e6a8f;     margin-left: -25px;">
          </div>
          <div class="signup-link">Already a member? <a href="Alogin.php" style="color: #67BFFF;">Login now</a></div>
        </form>
		
      </div>
    </div>

  </body>
</html>
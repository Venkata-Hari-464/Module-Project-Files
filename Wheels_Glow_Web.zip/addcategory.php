
<?php

	// session_start();
	// $name = $_SESSION['name'];
	
	
	
error_reporting(0);

$msg = "";

// If upload button is clicked ...
if (isset($_POST['upload'])) {


	$image = $_FILES["uploadfile"]["name"];
	$tempname = $_FILES["uploadfile"]["tmp_name"];
	$folder = "./images/" . $image;
	
	$informations = $_POST['informations'];
	
	$materials = $_POST['materials'];

	$category = $_POST['category'];


	// $name = $_SESSION['name'];
	
	$category1 = $_POST['category1'];
	

	$db = mysqli_connect("localhost", "root", "", "car");


	
	$sql = "INSERT INTO adddetails(image, informations, materials, category, category1) VALUES('$image','$informations','$materials','$catgory','$category1')";

	// Execute query
	mysqli_query($db, $sql);

	// Now let's move the uploaded image into the folder: image
	if (move_uploaded_file($tempname, $folder)) {
		echo "<h4> Register Successfully!</h4>";
	} else {
		echo "<h4>  Register Failed !</h4>";
	}
}
?>

<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="rename_style.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Home Page</title>
	<style>
	 body {
            overflow-x: hidden;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        
        header {
            background-color:#97dcd3;
            color: white;
            padding: 1px;
            text-align: center;
        }

        .hamburger {
            font-size: 20px;
            cursor: pointer;
        }

        .menu-bar {
            display: flex;
            align-items: center;
            font-size: 20px;
            cursor: pointer;
        }

        .menu-items {
            display: none;
            position: absolute;
            background-color: black;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            padding: 10px;
            left: 0;
            top: 40px;
            cursor: pointer;
        }

        .show-menu {
            display: block !important;
        }

        nav {
            background-color:#97dcd3;
            color: white;
            padding: 10px;
            text-align: center;
        }
        
        ul {
            list-style: none;
            padding: 0;
        }
        
        li {
            display: inline;
            margin-right: 20px;
        }
        
        a {
            text-decoration: none;
            color: black;
        }
        
        main {
            padding: 20px;
        }
        
        section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #a8f3e9;
            background-color: white;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        section h2 {
            text-align: center;
            color: black;
        }

        h2 {
            margin-top: 0;
        }

        /* Style for the dropdown menu */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Style for the dropdown button */
        .dropbtn {
            text-decoration: none;
            color: black;
            margin-right: 20px;
        }

        /* Style for the dropdown content */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #3333; /* Background color for dropdown */
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        /* Style for dropdown links */
        .dropdown-content a {
            color: white;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        /* Change color of dropdown links on hover */
        .dropdown-content a:hover {
            background-color: #444;
        }

        /* Display the dropdown content when hovering over the dropdown */
        .dropdown:hover .dropdown-content {
            display: block;
        }
        .img{
            padding-left: 68rem;
        
        }
     .service{
        height: 70px;
         width: 400px;
        background-color: #97dcd3;
        border-radius: 100px;
     }


     form .input-box input{
  height: 100%;
  width: 100%;
  outline: none;
  padding: 18px 15px;
  font-size: 12px;
  font-weight: 400;
  color: #333;
  border: 1.5px solid #1e6a8f;
  border-bottom-width: 2.5px;
  border-radius: 6px;
  transition: all 0.3s ease;
}
.input-box input:focus,
.input-box input:valid{
  border-color:#97dcd3;
}
form .policy{
  display: flex;
  align-items: center;
}
form h3{
  color: #707070;
  font-size: 14px;
  font-weight: 500;
  margin-left: 10px;
}
.input-box.button input{
  width: 300px;
    color: #fff;
    letter-spacing: 1px;
    border: none;
    background: #97dcd3;
    cursor: pointer;
    font-size: 21px;
}
.input-box.button input:hover{
  background: #97dcd3;
}
form .text h3{
 color: #333;
 width: 100%;
 text-align: center;
}
form .text h3 a{
  color:#97dcd3;
  text-decoration: none;
}
form .text h3 a:hover{
  text-decoration: underline;
}
    
.box{
  margin-top:10px;
  width:300px;
}
  form{
    height: 200px;
  }
  textarea{
    height: 100%;
  width: 100%;
  outline: none;
  padding: 18px 15px;
  font-size: 12px;
  font-weight: 400;
  color: #333;
  border: 1.5px solid #1e6a8f;
  border-bottom-width: 2.5px;
  border-radius: 6px;
  transition: all 0.3s ease;
    
  }


  @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');

*{
    list-style: none;
    text-decoration: none;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Open Sans', sans-serif;
}

body{
    background: #f5f6fa;
}

.wrapper .sidebar{
    background:black;
    position: fixed;
    top: 0;
    left: 0;
    width: 225px;
    height: 100%;
    padding: 20px 0;
    transition: all 0.5s ease;
}
.wrapper .sidebar ul li a{
    display: block;
    padding: 13px 30px;
    border-bottom: 1px solid black;
    color: rgb(241, 237, 237);
    font-size: 16px;
    position: relative;
}

.wrapper .sidebar ul li a .icon{
    color: #dee4ec;
    width: 30px;
    display: inline-block;
}
.wrapper .sidebar ul li a:hover,
.wrapper .sidebar ul li a.active{
    color: #0c7db1;

    background:white;
    border-right: 2px solid rgb(5, 68, 104);
}

.wrapper .sidebar ul li a:hover .icon,
.wrapper .sidebar ul li a.active .icon{
    color: #0c7db1;
}

.wrapper .sidebar ul li a:hover:before,
.wrapper .sidebar ul li a.active:before{
    display: block;
}
.wrapper .section{
    width: calc(100% - 225px);
    margin-left: 225px;
    transition: all 0.5s ease;
}

.wrapper .section .top_navbar{
    background:#97dcd3;
    height: 33px;
    display: flex;
    align-items: center;
    padding: 0 30px;

}

.wrapper .section .top_navbar .hamburger a{
    font-size: 28px;
    color: #f4fbff;
}

.wrapper .section .top_navbar .hamburger a:hover{
    color: #a2ecff;
}
body.active .wrapper .sidebar{
    left: -225px;
}

body.active .wrapper .section{
    margin-left: 0;
    width: 100%;
}
.hamburger {
    margin-bottom: -92px;
    font-size: 20px;
    cursor: pointer;
}
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins',sans-serif;
}
.alert_box,
.show_button{
  position: absolute;
  top: 50%;
  left: 51%;
  transform: translate(-50% , -50%);
}
.show_button{
  margin-top: 28em;
  height: 55px;
  padding: 0 30px;
  font-size: 20px;
  font-weight: 400;
  cursor: pointer;
  outline: none;
  border: none;
  color: #fff;
  line-height: 55px;
  background: #97dcd3;
  border-radius: 5px;
  transition: all 0.3s ease;
}
.show_button:hover{
  background: #97dcd3;
}
.background{
  position: bottom;
  height: 100%;
  width: 100%;
  top: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.5);
  opacity: 0;
  pointer-events: none;
  transition: all 0.3s ease;
}
.alert_box{
  padding: 30px;
  display: flex;
  background: #fff;
  flex-direction: column;
  align-items: bottom;
  text-align: center;
  max-width: 450px;
  width: 100%;
  border-radius: 5px;
  z-index: 5;
  opacity: 0;
  pointer-events: none;
  transform: translate(-50% , -50%) scale(0.97);
  transition: all 0.3s ease;
}
#check:checked ~ .alert_box{
  opacity: 1;
  pointer-events: auto;
  transform: translate(-50% , -50%) scale(1);
}
#check:checked ~ .background{
  opacity: 1;
  pointer-events: auto;
}
#check{
  display: none;
}
.alert_box .icon{
  height: 100px;
  width: 100px;
  color: #97dcd3;
  border: 3px solid #97dcd3;
  border-radius: 50%;
  line-height: 97px;
  font-size: 50px;
}
.alert_box header{
  font-size: 35px;
  font-weight: 500;
  margin: 10px 0;
}
.alert_box p{
  font-size: 20px;
}
.alert_box .btns{
  margin-top: 20px;
}
.btns label{
  display: inline-flex;
  height: 55px;
  padding: 0 30px;
  font-size: 20px;
  font-weight: 400;
  cursor: pointer;
  line-height: 55px;
  outline: none;
  margin: 0 10px;
  border: none;
  color: #97dcd3;
  border-radius: 5px;
  transition: all 0.3s ease;
}
.btns label:first-child{
  background: #97dcd3;
}
.btns label:first-child:hover{
  background: hidden;
}
.btns label:last-child{
  color:white;
  background: #97dcd3;
}
.btns label:last-child:hover{
  background: hidden;
}
.container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;

        }
        nav .logo a{
  font-weight: 500;
  font-size: 35px;
  color: white;
}
        .category-list {
            list-style: none;
            padding: 0;
            text-align: center;
        }
        .category-item1 {
            background-color: #fff;
            padding: 0px;
            border-radius: 5px;
            box-shadow: 0 0 40px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .category-item2 {
            background-color: #fff;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .category-icon {
            font-size: 48px;
            margin-bottom: 10px;
        }
        .category-title {
            font-size: 18px;
            font-weight: bold;
        }
        a{
            text-decoration: none;
            color:black;
        }
        .nav-links li a{
  text-decoration: none;
  color: white;
  font-size: 20px;
  font-weight: 500;
  padding: 10px 4px;
  transition: all 0.3s ease;
}
        nav{
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  padding: 11px;
  transition: all 0.4s ease;
  color:white;
  background-color:#1e6a8f;
}
p {
    margin-top: 0;
    margin-bottom: 0rem;
}
.logo{
    font-size:31px;
}
dl, ol, ul {
    margin-top: 0;
    margin-bottom: 0rem;
}
.form-control {
    display: block;
    width: 100%;
    height: calc(1.5em + 1.75rem + 2px);
    padding: 0.7rem 0.75rem;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}

    </style>

</head>

<body style="background-image:url('images/loginbgimg.jpg');background-size:cover; background-attachment:fixed;">
<nav>
    <div class="nav-content">
      <div class="logo" style="font-family:Open Sans, Arial, sans-serif; font-size:27px; font-weight:600;">
        WHEELS GLOW
      </div>
      <ul class="nav-links">
        <li><a href="adminhome.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">HOME</a></li>
        <li><a href="addservice.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;"> ADD SERVICE</a></li>
        <!--<li><a href="#">Financial Record</a></li>-->
        <!-- <li><a href="demo.php">Add Details </a></li> -->
        <li><a href="adminorder.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">ORDERS </a></li>
        <li><a href="logout.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">lOGOUT</a></li>
      </ul>
    </div>
  </nav><center>
	   <div id="content">
	  
		<mark>
				<?php if (isset($_GET['ms'])) {
					echo $_GET['ms'];
				} ?>
			</mark>
           <div style="background-color: #1e6a8f;width:382px; height:457px; margin-top:75px; padding-top:10px;">
			<h2><b style="margin-left:-18px; color:#67bfff; font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700; color:#fff;">ADD CATEGORY</b></h2>
                                <BR> 
                              <div class="box">
                                <form action="addcategorybackend.php" method="POST" enctype="multipart/form-data">

                                <div class="form-group">
				               <input class="form-control" type="file" name="uploadfile" value="" />
			                   </div><br />
                                    
                               <div class="input-box">
                                  
                                  <input type="text" name="servicename" placeholder="Service Name: " required>
                                </div><br>
                                    <div class="input-box">
                                  
                                  <textarea type="text" name="informations" placeholder="Information About : "  cols="43" rows="5"></textarea>
                                  </div><br>

                                 
                                  
          
                                     <!-- <div class="form-group col-mg-3">
                                     
                                      <select name ="service_type" class="form-control" style=" border: 2px solid; border-color: #1e6a8f;   margin-left: 5px; borderradius: 5px;height: 34px; width: 294px;color:grey;">

                                      <option value="" selected>categories</option>
                                      <option value="pressure carwash" >pressure carwash</option>
                                      <option value="under body clean" >under body clean</option>
                                      <option value="waterless clean" >waterless clean</option>
                                      <option value="car deep clean" >car deep clean</option>
                                      <option value="Wash and coat" >Wash and coat</option>
                                      </select>
                                     </div><br> -->
            
			
                                     <!-- <div class="form-group col-mg-3">
                                     
                                      <select name ="category1" class="form-control" style=" border: 2px solid;border-color: #1e6a8f;   margin-left: 5px;borderradius: 5px; height: 34px; width: 294px;color:grey;">

                                      <option value="" selected>categories</option>
                                      <option value="Hybrid Ceramic and Interior with underbody" >Hybrid ceramic and Inteior with underbody</option>
                                      <option value="Exterior and Interior with underbody" >Exterior and Interior with underbody</option>
                                      <option value="Exterior and Interior" >Exterior and Interior</option>
                                      <option value="Pressure Exterior Only" >Pessure Exterior Only</option>
                                      <option value="Waterless Exterior and Interior" >Waterless Exterior and Interior</option>

                                      <option value="Hybrid Ceramic and Interior with underbody" >Hybrid Ceramic and Interior with underbody</option>
                                      <option value="Exterior and Interior with underbody" >Exterior and Interior with underbody</option>
                                      <option value="Undercarriage Rinse" >Undercarriage Rinse</option>
                                      <option value="Undercarriage Rust Inhibitor" >Undercarriage Rust Inhibitor</option>
                                      <option value="Underbody Coating" >Underbody Coating</option>

                                      <option value="Waterless Exterior and Interior" >Waterless Exterior and Interior</option>
                                      <option value="Waterless Interior Only" >Waterless Interior Only</option>
                                      <option value="Waterless Exterior Only" >Waterless Exterior Only</option>
                                      <option value="Fleet Services" >Fleet Services</option>
                                      <option value="UV(ultraviolet) Protection" >UV(ultraviolet) Protection</option>

                                      <option value="Full Deep Clean and Exterior with coat" >Full Deep Clean and Exterior with coat</option>
                                      <option value="Interior Full Deep Clean" >Interior Full Deep Clean</option>
                                      <option value="Seat Deep CLean and Exterior" >Seat Deep CLean and Exterior</option>
                                      <option value="Roof Deep Clean and Exterior" >Roof Deep Clean and Exterior</option>
                                      <option value="Dashboard Deep CLean and Exterior" >Dashboard Deep CLean and Exterior</option>
                                      
                                      
                                      <option value="Hybrid Ceramic and Interior with underbody" >Hybrid Ceramic and Interior with underbody</option>
                                      <option value="Hybrid Ceramic and Interior" >Hybrid Ceramic and Interior</option>
                                      <option value="Wash and Wax" >Wash and Wax</option>
                                      <option value="Wash and Sealant" >Wash and Sealant</option>
                                      <option value="Wash and Polymer Coating" >Wash and Polymer Coating</option>
                                      </select>
                                      </div><br> -->
            
			<input type="submit" value="Submit" id = "btn_s" name="upload" style="background-color:#1e6a8f; border-width:0px; color:#fff;"><br/></br>
			
		
	</form>
        
        
	</div>
      </div>
            </center>
    
    
	
</body>

</html>

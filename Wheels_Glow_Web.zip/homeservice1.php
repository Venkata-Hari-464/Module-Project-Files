<?php 
session_start();


$db_host = 'localhost';
        $db_user = 'root';
        $db_pass = '';
        $db_name = 'car';

        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_GET['id'])){

          $service = $_GET['id'];
         
          $category = $_SESSION['service'];

        // Query to select all images from the table
        $sql = "SELECT * FROM servicename where service='$service' and category='$category' ";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Retrieve the image data
                $amt = $row['amount'];
                
              
               

   
  }
} else {
    echo 'No images data found in the table.';
}
        }
$conn->close();


?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="style4.css" />
    <style>
       .desktop .overlap-group {
    position: relative;
    width: 177px;
    height: 43px;
    background-color: #95b6f7;
    border-radius: 5px;
    top: -115px;
    left: -326px;
  }
      body{
        overflow-x:hidden;
      }
      label{
        margin-right: 464px;
      }
      input{
    height: 38px;
    margin-bottom: 96px;
    width: 612px;
    }
    .company{
      margin-top:150px;
    }
      p{
        margin-top: -50px;
       margin-right: 1px;
        
      }
      .yes-btn{
    height: 32px;
    width: 69px;
    color:black;
    border-width:0px;
    border-radius:5px;
    margin-left:314px;
}
.next-btn{
  height: 40px;
    width: 170px;
    background-color: #1e6a8f;
    color: white;
    border-width: 0px;
    border-radius: 5px;
    margin-left: 746px;
}
.details1{
  margin-top:19px;
  margin-left:30px;
  border-color:#67bfff;
  border-width:1px;
  border-radius:5px;
}
.details2{
 
  margin-left:30px;
  border-color:#67bfff;
  border-width:1px;
  border-radius:5px;
}
.details3{
 
  margin-left:30px;
  border-color:#67bfff;
  border-width:1px;
  border-radius:5px;
}
.page{
  margin-top: 125px;
}
.desktop .overlap {
    position: absolute;
    width: 1440px;
    height: 78px;
    top: -26px;
    left: -50px;
    background-color: #1e6a8f;
}
    </style>
  </head>
  <body>
    <div class="desktop">
      <div class="div">
        <div class="overlap">
        <div class="text-wrapper">Home Service</div></div>


        <!-- <img class="line" src="img/line-5.svg" />
        <img class="img" src="img/line-1.svg" />
        <img class="line-2" src="img/line-2.svg" />
        <img class="line-3" src="img/line-4.svg" /> -->


        <!-- <div class="text-wrapper-2">Vehicle Company
        <input type="text"  name="companyname"placeholder="Enter your vehicle company name" class="rectangle" required/>
        </div>
        <div class="text-wrapper-3">Vehicle Model </div>
        <div class="text-wrapper-4">Preffered Time</div>
        <p class="p">Want you change service type</p>
        <a href="services.php">
          <div class="group">
            <div class="overlap-group"><div class="text-wrapper-5">Yes</div></div>
          </div>
        </a>
        <a href="homeservice2.php">
          <div class="overlap-wrapper">
            <div class="div-wrapper"><div class="text-wrapper-6">Next</div></div>
          </div>
          <input type="submit" value="next">
        </a>
        <form>
        <input type="text"  name="companyname"placeholder="Enter your vehicle company name" class="rectangle" required/> -->
        <!-- <input type="text"  name="carmodel"placeholder="Enter your car model" class="rectangle-2" required/>
        <input type="text" name="service" placeholder="Enter your preffered time for service" class="rectangle-3"required/>
     <!--
        <input type="submit" value="next">   --> -->
<center><div class="page">
        <form action="homeservice1back.php" method="post">

        <input type="hidden" name="amount" value='<?php echo $amt; ?>'>
        <label class="company" style="font-family:sans-serif;"><b>Vehicle company</b></label><br>
  <input class="details1" type="text" id="username" name="companyname"  placeholder="Enter your vehicle company name"required><br>
  <div class="model1" style="margin-top:-29px; font-family:sans-serif;">

  <label style="margin-right:475px;"><b>Vehicle Model</b></label><br><br>
  <input class="details2" type="text" id="username" name="carmodel" placeholder="Enter your car model" required><br>
</div><div class="model2" style="margin-top:-24px; font-family:sans-serif;">

<label ><b>Preffered Date</b></label><br><br>
<input class="details3" type="date" id="username" name="date" placeholder="Enter your prefferd time for service" required><br>
  <div class="model2" style="margin-top:-19px; font-family:sans-serif;">
  
  <label ><b>Preffered Time</b></label><br><br>
<input class="details3" type="time" id="username" name="time" placeholder="Enter your prefferd time for service" required><br>
  <div class="model2" style="margin-top:-19px; font-family:sans-serif;">
 
  <label ><b>Address Line 1</b></label><br><br>
 <input class="details3" type="text" id="username" name="address1" placeholder="Enter your Address" required><br>
  <div class="model2" style="margin-top:-14px; font-family:sans-serif;">
 
  <label ><b>Address Line 2</b></label><br><br>
  <input class="details3" type="text" id="username" name="address2" placeholder="Enter your Address " required><br>
  <div class="model2" style="margin-top:-9px; font-family:sans-serif;">
  
  <label style="margin-right:520px;"><b>Pincode</b></label><br><br>
  <input class="details3" type="number" id="username" name="pincode" placeholder="Enter your Pincode" required><br>
  <div class="model2" style="margin-top:-4px; font-family:sans-serif;">
  
  <label style="margin-right:445px;"><b>Nearby Landmark</b></label><br><br>
  <input class="details3" type="text" id="username" name="landmark" placeholder="Enter your Nearby Landmark" required><br>
  <div class="model2" style="margin-top:1px; font-family:sans-serif;">
  
  <label ><b>Contact Number</b></label><br><br>
  <input class="details3" type="text" id="username" name="contactnumber" placeholder="Enter your contact number" required><br>
  <div class="model2" style="margin-top:6px; font-family:sans-serif;">
 
  <label style="margin-right:380px;"><b>Alternate Contact Number</b></label><br><br>
  <input class="details3" type="text" id="username" name="alternatecontactnumber" placeholder="Enter your alternate contact number" required><br>
 
  <a href="paymentindex.php">
    <button class="next-btn" style="margin-bottom:75px;">Continue</button>
  </a>
  <!-- <input type="submit" value="Next "> -->

      </form></div> </center>
    
  
  </body>
</html>

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="style5.css" />
    <style>
        .desktop .rectangle {
    width: 720px;
    height: 75px;
    background-color: #6af7dd;
    border-radius: 0px 0px 10px 10px;
    position: absolute;
    top: -11px;
    left: -65px;
  }
  .desktop .overlap {
    left: -65px;
    background-color: #d9d9d9;
    position: absolute;
    width: 720px;
    height: 75px;
    top: 99px;
    border-radius: 0px 0px 10px 10px;
  }
    </style>
  </head>
  <body>
    <div class="desktop">
      <div class="div">
        <a href="history.php">
            <div class="overlap"><div class="text-wrapper">Upcoming Bookings</div></div>
        </a>
        <div class="overlap-group">
          <div class="rectangle"></div>
          <div class="text-wrapper-2">History</div>
        </div>
        <p class="p">You have no bookings yet!</p>
        <div class="rectangle-2"></div>
      </div>
    </div>
  </body>
</html>

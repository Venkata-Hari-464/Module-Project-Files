<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Page </title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

    <style>

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;

        }
        .category-list {
            list-style: none;
            padding: 0;
            text-align: center;
        }
        .category-item {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .category-icon {
            font-size: 48px;
            margin-bottom: 10px;
        }
        .category-title {
            font-size: 18px;
            font-weight: bold;
        }
        a{
            text-decoration: none;
            color:black;
        }
    </style>
</head>
<body>
    <div class="container">
        <div style="text-align:center;">
            <h1 style="color: #67BFFF;">Services Offering</h1><br>
        <p style="color:#F4A329;">Dive into the portfolio of exceptional services we extend to our discerning clients.</p>
        </div>
        <br><br>
        <ul class="category-list">
                <li class="category-item d-flex flex-row">
                    <span class="category-icon"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLCqJRSgBDl0WLC2CK0bFYkPf7Tjd5bwq8Wg&usqp=CAU" alt=""></span>
                    <div class="ml-5 mt-5">
                        <h2 class="category-title">Pressure Car Wash</h2>
                        <p>Our high-pressure car wash ensures a thorough cleaning, removing dirt and grime from every nook and cranny of your vehicle.</p>
                    </div>
                </li>
            <li class="category-item d-flex flex-row">
                    <span class="category-icon"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRXBd36kNh8LPgBBzAHn_DX2t2hQqhQqaq7-Q&usqp=CAU" alt=""></span>
                    <div class="ml-5 mt-5">
                        <h2 class="category-title">Underbody Cleaning</h2>
                        <p>Our underbody cleaning service employs powerful techniques, ensuring a meticulous cleanse, eliminating dirt and debris from the often overlooked areas beneath your vehicle.</p>
                    </div>
                </li>
            <li class="category-item d-flex flex-row">
                    <span class="category-icon"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxETDxUPEBITFhAQEBUQEhAXFhgVFQ8QFRYXFhcXGBQYHSggGBslGxYVITEiJykrLi4uFyA/ODM4NygtLjIBCgoKDg0OFg8PGCslHx0tNy0rKy0tKy0tKy0rLTc3LSsrLSsrKysrLSsrLSstKystLSsrKy0rKysrLSsrKysrK//AABEIALwBDAMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABwMEBQYIAgH/xABCEAACAgECAgYGCAMECwAAAAAAAQIDEQQSBSEGBxMxQVEiMmFxgaEUI0JSgpGxwWJy0RUzkuE0RFNUY3OEosLD8P/EABYBAQEBAAAAAAAAAAAAAAAAAAABAv/EABcRAQEBAQAAAAAAAAAAAAAAAAABEQL/2gAMAwEAAhEDEQA/AJxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGzB9JOlGm0cfrpN2SWYUR52We5fZX8TwvaBm8lK7VQj684x97S/Uhbj/TbXatuFLdVX3K200v47u9v2LC95qmu4fqGtzcpy8m8/qwzenQt3SLSx776c/wDNrX6yRbPpNU/Unp3/ANTV+zZzHrMxlsaxJPDjyfM2Lon0Lt1t7g3soqf19zS9HHfGOeW7v9i737STq1PX9raqX91p6Jr730pY/wC2tmO1vTSFD26q7h9U/Gv6XKU1+Hsk/kRZ0m6UxjX/AGdwpdjoq8wldBuNmqn9pqfftz9rvl7u/UKNE3LEUlnm3/XzYa1PlfWbw1f3mppXlt7SS+daLqnrF4VLl9Mpj/M3D5ySOceK6dqOH4SXzyVtHDdXF+zD965fsE2upeH8X0963UXVWRfjCcZr84tl6mcqw07T3RzGfhOLcZL3SjzNw6OdP+IadRU5/SKu5wsfprHL0be/81ILKnsGD6MdJ6NbT2tWU4y2WVyWJVT79svhzT7mZwKAAAAAAAAAAAAAAAAAAAD42U53JLPz7kBVBaztfngpOK8XJ/EC+cl5opy1EPvL8yycYeWfzPmF5L8v6gYfpNxfW/3Ohp5v1tTPbth/JBvLftax7zS+H9D7p2zs1am92G5blKy+X8Us8kvIkz/7wX6HzC8gNI4hwaddD+i6ffZHGyqT2RfNJ5ks45ZZhI6Xie2Snw6Kez0HC3difm013Ep5PDviu9oJiEOC9XmsnqoSursglYrJTmvQSi9zy13t+Rl+lXSrRU3VcErlt0Snt19ylhzzndXvXPm/XkufPC8cSrLVwx3/ACMXRwjQw5w0mnTby32MMt+bbXNgxHeo6S9HopQVFM9qxHZG6cuX8W1fqYbQ0q1O+qrs4zbcKG5SlCOeSbSb5e3m/m5rqdcfUriv5YJfoistS/CMidTZjUuVz1x3g2unmNWivm3salCm2UXz+84JFbg/Rbiyq2vQ253vGY7XtePOS8ck6z1F27lF43d2YYx5t82XHaT8o/mJMmJULQ6H8Wkv9EUeWOcq1/7CtpegnF9rTqoTy8fWR5Z5+GfFvwJi3Wfw/kylbVZLHppY8NpRqnVp0Z1mj+kS1jrcr3XsUJbsKG/OeSx6yN8qua9xYV1zwk7G2lzeEsnp1P78gMo9ZFLMuSXe/BFwmaF0x4DLVUKuGolCcJb455xnya2vHd4c/A27gHafRKVc07VTBWSTypWKKUnn3phWQAAQAAAAAAAAAAAMHmx8n7gIq60+sHUaLWQ0tChtVEbpuSy5SlKaSzlYwoeXiYLiHWxmNSVUbLIwjZZOXKKtlFPbBY57fNrvMN1v6qmzV09rOyFv0delGtTi4b5d+ZJ5zuZrD0Wjvurp0eoknNQrSuqknO3nz9DKiuaXwAkngPW6p6iFeqgoVTbTtTzseG1lYXJtY7z5PrR1U1mvSWuO5pOGnnYnh4TUt6TXwKfRLq4qpn2utsjc1jbVGLUOX3m+cvd/mb6tLo4rC01OF/w4JL5AaRPpZxKVTsUL08cqoxgrFl8t0VVJxzz8Xyx3ZSfirpNr8KDd0tROPLT1N22xb5Lc87YpeMmseCzhm2X38MhLdOrRxk+WX2Kf5YM9VOEFtrhGMfKKUV+SLos+jE9XHTbuISr7TLksNNwqwsKySSi5LnlpYNO4/wBb1Fc3Xo6Z6hx5OxNQqz7Jc3L34x5MsOuXpFJRhw+uTXbR7W9p8+xTxGP4mnn2L2ke08PxFNwUm4yai5OKhJQlKKeGnNtpZ5pLPjzxBIvC+uaDmo63SzpjJ47SEu0ivesJr4ZJK0+sqshGyElKE4qUZrDUovuaa7zmu+mEnGuMNtllUJqKcnC2UoKTilJvDzlJp96+JvfU1xpqN2gm21VH6TT4vs20pxS97T98mBLbuj5B6n2GE4VxSvUU9tVNyhNvGVtcMcnFrvTTz3l7vAvXqjy9Uyz7QdoBdPUs8/SGW25nxZAru9nxXMpYZS1epVdc7Zd1cJTf4Vn9gNK6c9OboXPRaF/WQ5W3YUtkmk9sE/Ryk1mT5LKXu1nhHT7X6a6MtVY7tNLG/MYbowf24Tr5PGU9r8PfkwNClZWrJJu2+9TzjKlPdu258PS38+7u9h5jpJOuxuMpJRUM8o1R7KOMqUn9ZKSTWI+DYE99smlJNNNJp+DT5pmf6N25qa+7Npe5pP8AqR90NscuG6ZyfPsIxft25j/4okHo1Tijd9+bl8O79gMsAAAAAAAAAAAAAHxn0+MDmLrT4ReuIzk67J07F2ctrlCEcyzBSS88vH8RqHDtT2F8LoKO+mamovOG488NZOtdVwOiUZRi51ubzvhN5i191SzFe7GDXOKdEE65bdVXOzb6H0iiicM+UtsIyx8QI26K9MeIa7WRqjGmFUVvucYt7al4JybxJvkv8jW+sbj8r9XOEZt01SdUYZ9F7eUm13NuWfgjN09Kr+G6iUNVodMozeG9M4w3bftJxclL44+BhFbwa6x7adbDc29rtpjCOefrz/dgafJLD5LufgdScPu3U1yffKqEn8YpkJaX+xIWJ2VamSi84lYpxePNVxxJezJv9XWNw3Cxc0sYS7KxY9mNoGhdL9R23G7lJ+jC2FHmtlaSa/PcUISdslGc4zypNzhuU8tOPc4py9bvxlPHgYjV69T1t2pjzVmqsujnxi7HKOV7sGcjsrrlbBTcXCUlZFPLcoSqrhF/fi5ybfg15JMChPFcd0puG6b2utdpZOrnJRhN4jGHJPKlh4XeZXq8e3jbUeSdN8fdHcml8jFaScZVK+yP1OHJLxq1cX9ZXFfds9GTS5RznwebPo/0j+iauWq7PtJyrlXhy2rMpKTlnD8vmXq6kSvoeF26biVttbg9Bq12ltWZb6dRh5lCKjhqT7+f2n5I2d62vwrsf4f8yIbetfVfYopj7Xmb+eCxv6zeJy7rYw/lhFEVNsdRN+pp5fHCPTeo/wBlCP8ANI5+1HTTiM/W1VuPJSwvkY27iupn611j98mB0ZbqZR9fUaaH4llfmy0nxbTr19fX7oYf6HPMY3S7u0f+Jl5RwjWz9Sq5+6MgJ3r4xo2+V11j9kX+5hOnfSGiGhup3ONt9E41QmsSnu9Ftfm/yI10/Q7ik/V093xeP1Zfx6teLTXOlcu7dZHl82BYcEr3RjLPo0SzOOcNwclz9qx2mfdHz5V9JQ9QlZXHOovxTU2vXssbhsl/FD0nn7ko55rnl+H9WPGYS3RjTHwebfB96eIvK9htXA+rfXxsjdZqK4Trzs7PL7PKw8eikm8vuQEkcD6L6fTVwqhmUaoqEFJ5UUvZ4v2vJnEjXOHcJ1MF6epnP3pIzNVU13yyBdg8RTPYAAAAAAAAAAAeZJlvdVJ+JdADUuNdHbrk9uosj7E8L5Gg8Y6s9bLO29z9kpS/cms+YA5r1nVdxCOcVbvc0Ym/oBxGPfprPgmzqrahtQHJj6Ga/wD3W7/Az7HoRxF92lu/wtHWW1eQ2ryA5Ur6AcV+zo7Pkv1Zl+G9CONRyo6aUU+9Ode1+WYttP8AI6U2ryGAOf6+rDitz+vlVBdy+scml7IqOF8DIabqRf29Q/wx/qThg+gRFp+pXSr17bZfFL9jKafqh4fHvhOXvkySQBpWn6tOHR/1eD9+X+pk9P0O0UPV09S/Av6GxADG08Fpj6tcF7oouI6KC8EXQAorTx8j2qkewB52I+4PoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//Z" alt=""></span>
                    <div class="ml-5 mt-5">
                        <h2 class="category-title">Waterless Cleaning</h2>
                        <p>Our eco-friendly waterless cleaning method delivers a pristine shine, without a drop of water, leaving your vehicle spotless and environmentally responsible.</p>
                    </div>
                </li>
                <li class="category-item d-flex flex-row">
                    <span class="category-icon"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQb4HXVcuMrNLp1qTrdTdIQWlyWrDrODQbKgg&usqp=CAU" alt=""></span>
                    <div class="ml-5 mt-5">
                        <h2 class="category-title">Car Deep Clean</h2>
                        <p>Our car deep cleaning service goes beyond the surface, meticulously purging contaminants to restore your vehicle's interior to its pristine best.</p>
                    </div>
                </li>
                <li class="category-item d-flex flex-row">
                    <span class="category-icon"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9qSCA8RAqlLFJ4L4laZXFOaB7E7C-ztXO3w&usqp=CAU" alt=""></span>
                    <div class="ml-5 mt-5">
                        <h2 class="category-title">Wash and Coat</h2>
                        <p>Our wash and coat service provides a dual benefit, cleansing your vehicle while applying a protective layer, leaving it sparkling and shielded.</p>
                    </div>
                </li>
        </ul>
    </div>
</body>
</html>
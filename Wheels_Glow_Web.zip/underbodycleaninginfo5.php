<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="style3.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <style>
      .pop-up-btn{
        height:70px;
        width:400px;
        background-color:#a338f7;
        color:white;
        border-width:0px;
        border-radius:10px;
        margin-top:686px;
        margin-left:517px;
        font-weight:bold;
      }
      .desktop .overlap-wrapper {
    position: absolute;
    width: 556px;
    height: 0px;
    top: 652px;
    left: 426px;
}
.desktop .time-machine {
    position: absolute;
    width: 24px;
    height: 24px;
    top: -145px;
    left: 80px;
}
.desktop .image {
    width: 29px;
    height: 24px;
    top: -145px;
    left: 80px;
    position: absolute;
    object-fit: cover;
}
.desktop .paragraph {
    position: absolute;
    width: 523px;
    top: 460px;
    left: 135px;
    font-family: "Inter-Bold", Helvetica;
    font-weight: 700;
    color: #f4a228;
    font-size: 23px;
    letter-spacing: 0;
    line-height: normal;
}
      body{
        overflow-x: hidden;
      }
    </style>
  </head>
  <body>
    <div class="desktop">
      <div class="div">
        <div class="overlap"><div class="text-wrapper">Underbody Cleaning</div></div>
        <p class="p">Underbody Coating</p>
        <p class="paragraph">What's Included</p>
        <div class="group">
          <img class="time-machine" src="https://i.ibb.co/185fGgS/clock.png" />
          <p class="text-wrapper-2">Takes 1 hour time</p>
        </div>
        <div class="group-2">
          <p class="hybrid-ceramic-spray">
          Underbody coating in a car wash is the application of a protective layer or sealant to the vehicle's undercarriage, designed to safeguard it against corrosion,</br> rust, and damage caused by road debris, salt, and environmental factors.
          </p>
          <img class="image" src="https://i.ibb.co/bJQS413/like.jpg" />
        </div>
        <button type="button" class="pop-up-btn" data-toggle="modal" data-target="#exampleModal">
      Book Slot
    </button>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Car Wash</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            Select your type of Service
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <a href="paymentindex10.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Home serivice</button>
            </a>
            <a href="paymentindex10.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Showroom service</button>
            </a>
          </div>
        </div>
      </div>
    </div>
        <div class="overlap-wrapper">
          <div class="door-step-shampoo-wrapper">
            <p class="door-step-shampoo">
              -&gt; Rust
              Inhibitors&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              -&gt; Door Step<br /><br />-&gt; Detailing
              Spray&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&gt; Clay bar<br /><br />-&gt;
              Own power source&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&gt; Undercoating<br /><br />-&gt;
              Pumps and Plumbing&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&gt; Tyre polish<br /><br />-&gt;
              Waste Water Collection System
            </p>
          </div>
        </div>
        <img class="img" src="https://i.ibb.co/yBfpK0P/underbodycleaning5.jpg" />
      </div>
    </div>
  </body>
</html>

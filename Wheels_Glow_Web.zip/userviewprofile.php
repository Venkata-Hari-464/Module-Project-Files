<?php require_once("config.php");

	session_start();

	
	
//  $findresult = mysqli_query($conn, "SELECT * FROM user WHERE email= '$email'");
    $findresult = mysqli_query($db, "SELECT * FROM signup WHERE email='{$_SESSION['email']}'");
	

	
//  $sql = "SELECT username, name, department, address FROM signup WHERE username='{$_SESSION['username']}'";
if($res = mysqli_fetch_array($findresult))
{
 
$name = $res['name']; 
$email = $res['email']; 
// $_SESSION['phonenumber']=$Phonenumber;
$Phonenumber= $res['Phonenumber'];
}  
 ?> 
 <!DOCTYPE html>
<html>
<head>
    <title> My Account</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="rename_style.css">
    <style>

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;

        }
        nav .logo a{
  font-weight: 500;
  font-size: 35px;
  color: white;
}
        .category-list {
            list-style: none;
            padding: 0;
            text-align: center;
        }
        .category-item1 {
            background-color: #fff;
            padding: 0px;
            border-radius: 5px;
            box-shadow: 0 0 40px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .category-item2 {
            background-color: #fff;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .category-icon {
            font-size: 48px;
            margin-bottom: 10px;
        }
        .category-title {
            font-size: 18px;
            font-weight: bold;
        }
        a{
            text-decoration: none;
            color:black;
        }
        .nav-links li a{
  text-decoration: none;
  color: white;
  font-size: 20px;
  font-weight: 500;
  padding: 10px 4px;
  transition: all 0.3s ease;
}
        nav{
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  padding: 11px;
  transition: all 0.4s ease;
  color:white;
  background-color:#1e6a8f;
}
p {
    margin-top: 0;
    margin-bottom: 0rem;
}
.logo{
    font-size:31px;
}
dl, ol, ul {
    margin-top: 0;
    margin-bottom: 0rem;
}
    </style>
    
    <style>
	


body{ 
background:#EAE9E5;
 } 
 .login_form{
 	margin-top: 25%;
  background: #fff;
  padding: 30px; 
     box-shadow: 0px 1px 36px 5px rgba(0,0,0,0.28);
     border-radius: 5px;
 }
 .form_btn{ 
 	background: #fb641b;
    box-shadow: 0 1px 2px 0 rgba(0,0,0,.2);
    border: none;
    color: #fff; 
    width: 100% 
  }
  .label_txt{ 
font-size: 12px; 
   }  
   .form-control{border-radius: 25px }
   .signup_form{ 
    background: #fff;
  padding-left: 25px; 
   padding-right: 25px; 
      padding-bottom:5px; 
     box-shadow: 0px 1px 36px 5px rgba(0,0,0,0.28);
     border-radius: 5px;
    }
    .logo{ padding-right: 615px;
      height: 50px; 
      width: auto; 
        display: block;
  margin-left: auto;
  margin-right: auto;
     }
     .errmsg{ 
  margin: 2px auto;
  border-radius: 5px;
  border: 1px solid red;
  background: pink;
  text-align: left;
  color: brown;
  padding: 1px;
}
.successmsg {
    width: 135px;
    margin: 5px auto;
    border-radius: 5px;
    border: 1px solid green;
    background: #33CC00;
    text-align: left;
    color: white;
    padding: 10px;
}
.table td, .table th {
    padding: 0.75rem;
    vertical-align: top;
    border-top: 1px solid #dee2e6;
    font-family: Open Sans, Arial, sans-serif;
}
p {
    margin-top: 0;
    margin-bottom: 0rem;
    font-family: Open Sans, Arial, sans-serif;
}
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-decoration: none;
    font-family: Open Sans, Arial, sans-serif;
}
</style>
</head>
<body>
<nav>
    <div class="nav-content">
      <div class="logo" style="font-family:Open Sans, Arial, sans-serif; font-size:27px; font-weight:600;">
        WHEELS GLOW
      </div>
      <ul class="nav-links">
        <li><a href="services.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">HOME</a></li>
        <!-- <li><a href="history.php">History</a></li> -->
        <!--<li><a href="#">Financial Record</a></li>-->
        <li><a href="userviewprofile.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">PROFILE</a></li>
       <li><a href="userorder.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">USER BOOKING </a></li>
       <li><a href="logout.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">LOGOUT</a></li>
      </ul>
    </div>
  </nav>

<div class="container">
    <div class="row">
        <div class="col-sm-3">
            
        </div>
        <div class="col-sm-6">
  <div class="login_form">
<!-- <img src="https://technosmarter.com/assets/images/logo.png" alt="Techno Smarter" class="logo img-fluid"> <br> -->
     
          <div class="row">
            <div class="col"></div>
           <div class="col-6"> 
             <?php if(isset($_GET['profile_updated'])) 
      { ?>
    <div class="successmsg">Profile saved ..</div>
      <?php } ?>
        <?php if(isset($_GET['password_updated'])) 
      { ?>
    <div class="successmsg">Password has been changed...</div>
      <?php } ?>
            <center>
            <!-- <?php if($image==NULL)
                {
                 echo '<img src="https://technosmarter.com/assets/icon/user.png">';
				 
//				 <img src="images/'.$row['filename'].'" height="200">
                } else { echo '<img src="images/'.$res['image'].'" style="height:80px;width:auto;border-radius:50%;">';}?> 
                 -->
               
  <p> Welcome! <span style="color:#33CC00"><?php echo $name; ?></span> </p>
  </center>
           </div>
            <div class="col"><p><a href="logout.php"><span style="color:red;"></span> </a></p>
            <!-- <p>            <a href="homepageuser.php"><span style="color:red;">Go Back</span> </a></p> -->
         </div>
          </div>

          <table class="table">
          <tr>
              <th>Name </th>
              <td><?php echo $name; ?></td>
          </tr>
          <tr>
              <th>Email</th>
              <td><?php echo $email; ?></td>
          </tr>
          <tr>
              <th>Contact Number</th>
              <td><?php echo $Phonenumber; ?></td>
          </tr>
          </table>
           <div class="row">
            <div class="col-sm-2">
            </div>
             <div class="col-sm-4">
                <a href="usereditprofile.php"><button type="button" class="btn btn-primary">Edit Profile</button></a>
            </div>
            <!-- <div class="col-sm-6">
         <a href="userchangepassword.php"><button type="button" class="btn btn-warning">Change Password</button></a>
            </div> -->
           </div>
        </div>
        <div class="col-sm-3">
        </div>
    </div>
</div> 
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</html>
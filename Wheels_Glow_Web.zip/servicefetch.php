<?php 
 session_start();
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="style1.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="rename_style.css">

    <link href="css1/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <style>
    .price-block {
    box-shadow: 0px 0px 0px 0px rgba(0,0,0,0.15);
   
}
      *{font-family:"Open Sans", Arial, sans-serif;
        font-size:14px;
      }
      .pop-up-btn{
        height:28px;
        width:100px;
        background-color: #1e6a8f;
        color:white;
        border-width:0px;
        border-radius:3px;
        margin-top:165px;
        margin-left:105px;
      }
        .desktop .text-wrapper-6 {
    position: absolute;
    top: 30px;
    left: 470px;
    font-family:"Open Sans", Arial, sans-serif;
    font-weight: 700;
    color: #000000;
    font-size: 14px;
    letter-spacing: 0;
    line-height: normal;
    white-space: nowrap;
}
.desktop .image {
    position: absolute;
    width: 388px;
    height: 213px;
    top: 128px;
    left: 440px;
    object-fit: cover;
}
.desktop .overlap {
  margin-left: 40px;
    position: relative;
    width: 325px;
    height: 220px;
    top: 160px;
    left: 51px;
    background-color: #f1ecec;
    border-radius: 10px;
    box-shadow: 0px 6px 4px #00000040;
}
.desktop .text-wrapper {
    position: absolute;
    width: 297px;
    top: 28px;
    left: 23px;
    font-family:"Open Sans", Arial, sans-serif;
    font-weight: 700;
    color: #000000;
    font-size: 16px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .waterless-cleaning {
    position: absolute;
    top: 71px;
    left: 23px;
    font-family:"Open Sans", Arial, sans-serif;
    font-weight: 400;
    color: #000000;
    font-size: 16px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .text-wrapper-3 {
    position: absolute;
    top: 125px;
    left: 23px;
    font-family:"Open Sans", Arial, sans-serif;
    font-weight: 400;
    color: #185bdc;
    font-size: 14px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .div {
    background-color: lightgray;
    width: 1440px;
    height: 586px;
    position: relative;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
}

html, body {
    margin: 0;
    font-size: 100%;
    font-family: 'Lato', sans-serif;
    background: lightgray;
}
        </style>
        

    <style>

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;

}
nav .logo a{
font-weight: 500;
font-size: 35px;
color: white;
}
.category-list {
    list-style: none;
    padding: 0;
    text-align: center;
}
.category-item1 {
    background-color: #fff;
    padding: 0px;
    border-radius: 5px;
    box-shadow: 0 0 40px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}
.category-item2 {
    background-color: #fff;
    padding: 10px;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}
.category-icon {
    font-size: 48px;
    margin-bottom: 10px;
}
.category-title {
    font-size: 18px;
    font-weight: bold;
}
a{
    text-decoration: none;
    color:black;
}
.nav-links li a{
text-decoration: none;
color: white;
font-size: 20px;
font-weight: 500;
padding: 10px 4px;
transition: all 0.3s ease;
}
nav{
position: fixed;
top: 0;
left: 0;
width: 100%;
padding: 14px;
transition: all 0.4s ease;
color:white;
background-color:#1e6a8f;
}
p {
margin-top: 0;
margin-bottom: 0rem;
}
.logo{
font-size:31px;
}
dl, ol, ul {
    margin-top: 0;
    margin-bottom: 0rem;
}
.desktop .text-wrapper-4 {
    position: absolute;
    top: 170px;
    left: 22px;
    font-family: "Inter-Regular", Helvetica;
    font-weight: 400;
    color: #1e6a8f;
    font-size: 19px;
    letter-spacing: 0;
    line-height: normal;
}
</style>
  </head>
  <body>
    <div class="desktop" >
      <div class="div" >
        <!-- <img class="image" src="images/subservicesimg.jpeg" /> -->
        
        <?php
        
        // Database connection
        $db_host = 'localhost';
        $db_user = 'root';
        $db_pass = '';
        $db_name = 'car';

        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_GET['service'])){
          $service = $_GET['service'];
          $_SESSION['service'] = $service;
          

       
        // Query to select all images from the table
        $sql = "SELECT * FROM servicename where category='$service'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Retrieve the image data
                $service = $row['service'];
                $time = $row['time'];
                $details = $row['details']; 
                $amount = $row['amount'];
                $materials = $row['materials'];


// connect a header only and put into echo same as below
echo'<nav>';
  echo'  <div class="nav-content">';
   echo'   <div class="logo" style="font-family:Open Sans, Arial, sans-serif; font-size:27px; font-weight:600;">';
        echo'WHEELS GLOW';
     echo' </div>';
      echo'<ul class="nav-links">';
       echo' <li><a href="services.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">SERVICES</a></li>';
    
        echo'<li><a href="userviewprofile.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">PROFILE</a></li>';
      echo' <li><a href="userorder.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">USER BOOKING </a></li>';
       echo'<li><a href="logout.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">LOGOUT</a></li>';
      echo'</ul>';
   echo' </div>';
 echo'</nav>';
echo'<br>';
echo'<div class="price-block agile">';
      echo'  <div class="overlap">';
        echo'  <div class="text-wrapper">'.$service.'</div>';
          echo'<p class="waterless-cleaning">'.$materials.'</p>';
          echo'<button type="button" class="pop-up-btn" data-toggle="modal" data-target="#exampleModal">
            Available
          </button>';
        //  echo' <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">';
        //   echo'  <div class="modal-dialog">';
        //      echo' <div class="modal-content">';
        //        echo' <div class="modal-header">';
        //         echo'  <h5 class="modal-title" id="exampleModalLabel">Wheels Glow</h5>';
        //          echo' <button type="button" class="close" data-dismiss="modal" aria-label="Close">';
        //           echo'  <span aria-hidden="true">&times;</span>';
        //         echo'  </button>';
        //         echo'</div>';
        //        echo' <div class="modal-body">';
        //          echo' Select your type of Service';
        //        echo' </div>';
        //         echo'<div class="modal-footer">';
        //         echo'  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>';
        //          echo' <a href="homeservice1.php?amt='.$amount.'">';
        //          echo'   <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Home Service</button>';
        //          echo' </a>';
        //         echo'  <a href="paymentindex.php?category='.$service.'">';
        //          echo'   <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Showroom Service</button>';
        //         echo'  </a>';
        //        echo' </div>';
        //      echo' </div>';
        //    echo '</div>';
        //    echo' </div>';
            echo'<div class="text-wrapper-3" ><a href="pressurecarwashinfo1.php?category='.$service.'" style="text-decoration:none;">'.$details.'</a></div>';
           echo' <div class="text-wrapper-4">Rs.'.$amount.'</div>';
          echo'  <div class="group-2">';
           echo'   <img class="time-machine" src="https://i.ibb.co/185fGgS/clock.png"/>';
           echo'   <div class="text-wrapper-5">'.$time.'</div>';
           echo' </div>';
         echo' </div>';
         echo'</div>';
        
        }
    } else {
        echo 'No images found in the table.';
    }
  }
    $conn->close();
    ?>
      </div>
      
    </div>
  </body>
</html>

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="style1.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <style>
      .pop-up-btn{
        height:28px;
        width:100px;
        background-color:#a338f7;
        color:white;
        border-width:0px;
        border-radius:3px;
        margin-top:165px;
        margin-left:105px;
      }
        .desktop .text-wrapper-6 {
    position: absolute;
    top: 30px;
    left: 470px;
    font-family: "Inter-Bold", Helvetica;
    font-weight: 700;
    color: #ffffff;
    font-size: 25px;
    letter-spacing: 0;
    line-height: normal;
    white-space: nowrap;
}
.desktop .image {
    position: absolute;
    width: 388px;
    height: 213px;
    top: 105px;
    left: 440px;
    object-fit: cover;
}
.desktop .overlap {
    position: absolute;
    width: 325px;
    height: 220px;
    top: 372px;
    left: 51px;
    background-color: #f1ecec;
    border-radius: 10px;
    box-shadow: 0px 6px 4px #00000040;
}
.desktop .text-wrapper {
    position: absolute;
    width: 297px;
    top: 19px;
    left: 23px;
    font-family: "Inter-Bold", Helvetica;
    font-weight: 700;
    color: #000000;
    font-size: 16px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .waterless-cleaning {
    position: absolute;
    top: 55px;
    left: 23px;
    font-family: "Inter-Regular", Helvetica;
    font-weight: 400;
    color: #000000;
    font-size: 16px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .text-wrapper-3 {
    position: absolute;
    top: 125px;
    left: 23px;
    font-family: "Inter-Regular", Helvetica;
    font-weight: 400;
    color: #185bdc;
    font-size: 19px;
    letter-spacing: 0;
    line-height: normal;
}
.header-container{
    background-color:#67bfff;
    height:75px;
    width:1440px;
  }
  body{
    overflow-x:hidden;
    margin-left:181px;
  }
        </style>
  </head>
  <body>
    <div class="desktop">
      <div class="div">
        <img class="image" src="https://i.ibb.co/ThfMXdZ/waterless.jpg" />
        <div class="overlap">
          <div class="text-wrapper">Waterless Exterior and Interior</div>
          <p class="waterless-cleaning">-&gt; Waterless Cleaning<br />-&gt; Vaccum Cleaning</p>
          <button type="button" class="pop-up-btn" data-toggle="modal" data-target="#exampleModal">
      Book Slot
    </button>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Car Wash</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            Select your type of Service
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <a href="paymentindex11.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Home Service</button>
            </a>
            <a href="paymentindex11.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Showroom Service</button>
            </a>
          </div>
        </div>
      </div>
    </div>
          <div class="text-wrapper-3"><a href="waterlesscleaninginfo1.php">+9 More</a></div>
          <div class="text-wrapper-4">Rs.349</div>
          <div class="group-2">
            <img class="time-machine" src="https://i.ibb.co/185fGgS/clock.png"/>
            <div class="text-wrapper-5">60 mins</div>
          </div>
        </div>
        <div class="overlap-2">
          <div class="text-wrapper">Waterless Interior Only</div>
          <p class="waterless-cleaning">-&gt; Vaccum Cleaning<br />-&gt; Dashboard Cleaning</p>
          <button type="button" class="pop-up-btn" data-toggle="modal" data-target="#exampleModal">
      Book Slot
    </button>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Car Wash</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            Select your type of Service
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <a href="paymentindex12.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Home Service</button>
            </a>
            <a href="paymentindex12.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Showroom Service</button>
            </a>
          </div>
        </div>
      </div>
    </div>
          <div class="text-wrapper-3"><a href="waterlesscleaninginfo2.php">+9 More</a></div>
          <div class="text-wrapper-4">Rs.249</div>
          <div class="group-2">
            <img class="time-machine" src="https://i.ibb.co/185fGgS/clock.png" />
            <div class="text-wrapper-5">30 mins</div>
          </div>
        </div>
        <div class="overlap-3">
          <div class="text-wrapper"> Waterless Exterior Only</div>
          <p class="waterless-cleaning">-&gt; Waterless Cleaning<br />-&gt; Tyre Polish</p>
          <button type="button" class="pop-up-btn" data-toggle="modal" data-target="#exampleModal">
      Book Slot
    </button>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Car Wash</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            Select your type of Service
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <a href="paymentindex13.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Home Service</button>
            </a>
            <a href="paymentindex13.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Showroom Service</button>
            </a>
          </div>
        </div>
      </div>
    </div>
          <div class="text-wrapper-3"><a href="waterlesscleaninginfo3.php">+9 More</a></div>
          <div class="text-wrapper-4">Rs.199</div>
          <div class="group-2">
            <img class="time-machine" src="https://i.ibb.co/185fGgS/clock.png" />
            <div class="text-wrapper-5">30 mins</div>
          </div>
        </div>
        <div class="overlap-4">
          <div class="text-wrapper">Fleet Services</div>
          <p class="waterless-cleaning">-&gt; Vehicle Fleet<br />-&gt; Traditional Washing Methods</p>
          <button type="button" class="pop-up-btn" data-toggle="modal" data-target="#exampleModal">
      Book Slot
    </button>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Car Wash</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            Select your type of Service
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <a href="paymentindex14.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Home Service</button>
            </a>
            <a href="paymentindex14.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Showroom Service</button>
            </a>
          </div>
        </div>
      </div>
    </div>
          <div class="text-wrapper-3"><a href="waterlesscleaninginfo4.php">+9 More</a></div>
          <div class="text-wrapper-4">Rs.199</div>
          <div class="group-2">
            <img class="time-machine" src="https://i.ibb.co/185fGgS/clock.png" />
            <div class="text-wrapper-5">30 mins</div>
          </div>
        </div>
        <div class="overlap-5">
          <div class="text-wrapper">UV(ultraviolet) Protection</div>
          <p class="waterless-cleaning">-&gt; Paint Protection<br />-&gt; Interior Protection</p>
          <button type="button" class="pop-up-btn" data-toggle="modal" data-target="#exampleModal">
      Book Slot
    </button>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Car Wash</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            Select your type of Service
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <a href="paymentindex15.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Home Service</button>
            </a>
            <a href="paymentindex15.php">
              <button type="button" class="btn btn-primary" style="background-color:#a338f7;border-color:#a338f7;">Showroom Service</button>
            </a>
          </div>
        </div>
      </div>
    </div>
          <div class="text-wrapper-3"><a href="waterlesscleaninginfo5.php">+9 More</a></div>
          <div class="text-wrapper-4">Rs.349</div>
          <div class="group-2">
            <img class="time-machine" src="https://i.ibb.co/185fGgS/clock.png" />
            <div class="text-wrapper-5">60 mins</div>
          </div>
        </div>
        <div class="header-container"><div class="text-wrapper-6">Waterless cleaning</div></div>
      </div>
    </div>
  </body>
</html>

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="style5.css" />
  </head>
  <body>
    <div class="desktop">
      <div class="div">
        <div class="overlap"><div class="text-wrapper">Upcoming Bookings</div></div>
        <div class="overlap-group">
        <a href="history2.php">
            <div class="rectangle"></div>
            <div class="text-wrapper-2">History</div>
        </a>
        </div>
        <p class="p">You have no bookings yet!</p>
        <div class="rectangle-2"></div>
      </div>
    </div>
  </body>
</html>

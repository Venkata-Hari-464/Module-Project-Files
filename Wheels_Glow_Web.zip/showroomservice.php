<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="style4.css" />
    <style>
        .desktop .text-wrapper-6 {
    position: absolute;
    width: 180px;
    top: 11px;
    left: 50px;
    font-family: "Inter-Bold", Helvetica;
    font-weight: 700;
    color: #ffffff;
    font-size: 17px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .text-wrapper {
    position: absolute;
    width: 215px;
    top: 23px;
    left: 535px;
    font-family: "Inter-Bold", Helvetica;
    font-weight: 700;
    color: #f5f5f5;
    font-size: 30px;
    letter-spacing: 0;
    line-height: normal;
    white-space: nowrap;
}
      body{
        overflow-x:hidden;
      }
    </style>
  </head>
  <body>
    <div class="desktop">
      <div class="div">
        <div class="overlap"><div class="text-wrapper">Showroom Service</div></div>
        <img class="line" src="img/line-5.svg" />
        <img class="img" src="img/line-1.svg" />
        <img class="line-2" src="img/line-2.svg" />
        <img class="line-3" src="img/line-4.svg" />
        <div class="text-wrapper-2">Vehicle Company</div>
        <div class="text-wrapper-3">Vehicle Model</div>
        <div class="text-wrapper-4">Preffered Time</div>
        <p class="p">Want you change service type</p>
        <a href="services.php">
          <div class="group">
            <div class="overlap-group"><div class="text-wrapper-5">Yes</div></div>
          </div>
        </a>
          <div class="overlap-wrapper">
            <div class="div-wrapper"><div class="text-wrapper-6">Continue to payment</div></div>
          </div>
        <input type="text" placeholder="Enter your vehicle company name" class="rectangle"/>
        <input type="text" placeholder="Enter your car model" class="rectangle-2"/>
        <input type="text" placeholder="Enter your preffered time for service" class="rectangle-3"/>
      </div>
    </div>
  </body>
</html>

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="style4.css" />
    <style>
        .desktop .overlap {
    position: absolute;
    width: 1440px;
    height: 78px;
    top: -10px;
    left: -10px;
    background-color: #67bfff;
}
.desktop .text-wrapper {
    position: absolute;
    width: 215px;
    top: 23px;
    left: 565px;
    font-family: "Inter-Bold", Helvetica;
    font-weight: 700;
    color: #f5f5f5;
    font-size: 30px;
    letter-spacing: 0;
    line-height: normal;
    white-space: nowrap;
}
.desktop .text-wrapper-2 {
    width: 399px;
    top: 118px;
    position: absolute;
    left: 130px;
    font-family: "Inter-Regular", Helvetica;
    font-weight: 400;
    color: #000000;
    font-size: 17px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .rectangle {
    top: 163px;
    position: absolute;
    width: 700px;
    height: 41px;
    left: 130px;
    background-color: #ffffff;
    border-color: #4070f4;
    border-width: 1px;
    border-radius: 5px;
}
.desktop .text-wrapper-3 {
    width: 323px;
    top: 240px;
    position: absolute;
    left: 130px;
    font-family: "Inter-Regular", Helvetica;
    font-weight: 400;
    color: #000000;
    font-size: 17px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .rectangle-2 {
    top: 287px;
    position: absolute;
    width: 700px;
    height: 41px;
    left: 130px;
    background-color: #ffffff;
    border-color: #4070f4;
    border-width: 1px;
    border-radius: 5px;
}
.desktop .text-wrapper-4 {
    position: absolute;
    width: 343px;
    top: 364px;
    left: 130px;
    font-family: "Inter-Regular", Helvetica;
    font-weight: 400;
    color: #000000;
    font-size: 17px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .rectangle-3 {
    top: 415px;
    position: absolute;
    width: 700px;
    height: 41px;
    left: 130px;
    background-color: #ffffff;
    border-color: #4070f4;
    border-width: 1px;
    border-radius: 5px;
}
.desktop .div-wrapper {
    position: relative;
    width: 268px;
    height: 42px;
    background-color: #a339f7;
    border-radius: 5px;
    top: -90px;
    left: -70px;
}
.desktop .rectangle-4 {
    top: 545px;
    position: absolute;
    width: 700px;
    height: 41px;
    left: 130px;
    background-color: #ffffff;
    border-color: #4070f4;
    border-width: 1px;
    border-radius: 5px;
}
.desktop .rectangle-5 {
    top: 670px;
    position: absolute;
    width: 700px;
    height: 41px;
    left: 130px;
    background-color: #ffffff;
    border-color: #4070f4;
    border-width: 1px;
    border-radius: 5px;
}
.desktop .rectangle-6 {
    top: 800px;
    position: absolute;
    width: 700px;
    height: 41px;
    left: 130px;
    background-color: #ffffff;
    border-color: #4070f4;
    border-width: 1px;
    border-radius: 5px;
}
.desktop .text-wrapper-5 {
    position: absolute;
    width: 400px;
    top: 495px;
    left: 130px;
    font-family: "Inter-Regular", Helvetica;
    font-weight: 400;
    color: #000000;
    font-size: 17px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .text-wrapper-6 {
    position: absolute;
    width: 400px;
    top: 620px;
    left: 130px;
    font-family: "Inter-Regular", Helvetica;
    font-weight: 400;
    color: #000000;
    font-size: 17px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .text-wrapper-7 {
    position: absolute;
    width: 400px;
    top: 750px;
    left: 130px;
    font-family: "Inter-Regular", Helvetica;
    font-weight: 400;
    color: #000000;
    font-size: 17px;
    letter-spacing: 0;
    line-height: normal;
}
.desktop .div-wrapper {
    position: relative;
    width: 268px;
    height: 42px;
    background-color: #a339f7;
    border-radius: 5px;
    top: 150px;
    left: -70px;
}
.desktop .text-wrapper-8 {
    position: absolute;
    width: 400px;
    top: 13px;
    left: 115px;
    font-family: "Inter-Regular", Helvetica;
    font-weight: 600;
    color: #ffffff;
    font-size: 17px;
    letter-spacing: 0;
    line-height: normal;
}
      body{
        overflow-x:hidden;
      }
    </style>
  </head>
  <body>
    <div class="desktop">
      <div class="div">
        <div class="overlap"><div class="text-wrapper">Home Service</div></div>
        <img class="line" src="img/line-5.svg" />
        <img class="img" src="img/line-1.svg" />
        <img class="line-2" src="img/line-2.svg" />
        <img class="line-3" src="img/line-4.svg" />
        <div class="text-wrapper-2" for="address1">Address Line 1</div>
        <div class="text-wrapper-3">Address Line 2</div>
        <div class="text-wrapper-4">Pincode</div>
        <div class="text-wrapper-5">Nearby Landmark</div>
        <div class="text-wrapper-6">Contact Number</div>
        <div class="text-wrapper-7">Alternate Contact Number</div>
        <div class="overlap-wrapper">
        <form action="homeservice2.php" method="post">
        <div class="div-wrapper"><a href="services.php"><div class="text-wrapper-8">Next</div></a></div>
            </div>
                <input type="text" placeholder="Enter your Address" class="rectangle" id="address1" name="address1" required/>
                <input type="text" placeholder="Enter your Address" class="rectangle-2"/>
                <input type="text" placeholder="Enter your Pincode" class="rectangle-3"/>
                <input type="text" placeholder="Enter your Nearby Landmark" class="rectangle-4"/>
                <input type="text" placeholder="Enter your Contact Number" class="rectangle-5"/>
                <input type="text" placeholder="Enter your Alternate Contact Number" class="rectangle-6"/>
            </div>
        </form>
    </div>
  </body>
</html>

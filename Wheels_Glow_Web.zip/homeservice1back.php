<?php
session_start();
 $servername = "localhost";

    $username = "root";

    $password = "";

    $dbname = "car"; 
	
	$message = "Register successful";
	
	
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$companyname = $_POST['companyname'];
$carmodel= $_POST['carmodel'];
$date = $_POST['date'];
$time = $_POST['time'];
$address1 = $_POST['address1'];
$address2 = $_POST['address2'];
$amount = $_POST['amount'];
$pincode = $_POST['pincode'];
$landmark = $_POST['landmark'];
$contactnumber = $_POST['contactnumber'];
$alternatecontactnumber = $_POST['alternatecontactnumber'];
$id=$_SESSION["id"];

     $sql = "INSERT INTO car_details(companyname , carmodel, date, time, address1, address2, pincode, landmark, contactnumber, alternatecontactnumber,status, user_id, amount) VALUES('$companyname','$carmodel','$date','$time','$address1','$address2','$pincode','$landmark','$contactnumber','$alternatecontactnumber','Booking','$id','$amount')";
	 

if ($conn->query($sql) === TRUE) {
  
  echo "<script type='text/javascript'>alert('$message');window.location.href='services.php';</script>";
  
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
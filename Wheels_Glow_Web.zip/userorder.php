<?php 
session_start();
require_once("config.php");?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="style.css">
	<title>Admin Order </title>
    
    
    
    <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script> 
		

        
        
    <style>
    .foto_style img {
  width: 50px; 
  height:50px;
}​




/* Style The Dropdown Button */
.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #f1f1f1}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
  display: block;
}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}

</style>


		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous"> -->
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
		<link rel="stylesheet" href="log/css/all.css">
		<link rel="stylesheet" href="log/css/bootstrap.css">
		<link rel="stylesheet" href="log/css/style.css">
		<link rel="stylesheet" href="log/css/media.css">
        
		
<style>
  table{
    margin-top: 43px;
  }
		table, tr, th, td {
			border: 1px solid #aaa;
			border-collapse: collapse;
			padding: 5px;
      margin-right:25px;
      margin-left:85px;
      border-color: black;
      margin-bottom: 15px;
      font-family: Open Sans, Arial, sans-serif;
      font-size: 14px;
      text-align:center;
}
		
		th {
       background: #eee
    }
		
	
	</style>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="rename_style.css">

    <style>

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;

}
nav .logo a{
font-weight: 500;
font-size: 35px;
color: white;
}
.category-list {
    list-style: none;
    padding: 0;
    text-align: center;
}
.category-item1 {
    background-color: #fff;
    padding: 0px;
    border-radius: 5px;
    box-shadow: 0 0 40px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}
.category-item2 {
    background-color: #fff;
    padding: 10px;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}
.category-icon {
    font-size: 48px;
    margin-bottom: 10px;
}
.category-title {
    font-size: 18px;
    font-weight: bold;
}
a{
    text-decoration: none;
    color:black;
}
.nav-links li a{
text-decoration: none;
color: white;
font-size: 20px;
font-weight: 500;
padding: 10px 4px;
transition: all 0.3s ease;
}
nav{
position: fixed;
top: 0;
left: 0;
width: 100%;
padding: 11px;
transition: all 0.4s ease;
color:white;
background-color:#1e6a8f;
}
p {
margin-top: 0;
margin-bottom: 0rem;
}
.logo{
font-size:31px;
}
dl, ol, ul {
    margin-top: 0;
    margin-bottom: 0rem;
}
</style>

</head>
<body>

<nav>
    <div class="nav-content">
      <div class="logo" style="font-family:Open Sans, Arial, sans-serif; font-size:27px; font-weight:600;">
        WHEELS GLOW
      </div>
      <ul class="nav-links">
        <li><a href="services.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">HOME</a></li>
        <!-- <li><a href="history.php">History</a></li> -->
        <!--<li><a href="#">Financial Record</a></li>-->
        <li><a href="userviewprofile.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">PROFILE</a></li>
       <li><a href="userorder.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">USER BOOKING </a></li>
       <li><a href="logout.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">LOGOUT</a></li>
      </ul>
    </div>
  </nav>


<br><br>


	
<div class="container_display">
		
		
	<table>
		<tr>

			<th>Company Name</th>
            <th>Car Model</th>
			<th>Date</th>
            <th>Time</th>
            <th>Address1</th>
            <th>Address2</th>
            <th>Pincode</th>
            <th>Landmark</th>
            <th>Contact Number</th>
            <th>Altenate Contact Number</th>
            <th>Staus</th>
            <th>Payment</th>
            
            
		</tr>
    <?php

$id = $_SESSION["id"];

$res = mysqli_query($db, "SELECT * FROM car_details WHERE user_id='$id'");
while ($row = mysqli_fetch_array($res)) {
    echo '<tr> 
        <td>' . $row['companyname'] . '</td> 
        <td>' . $row['carmodel'] . '</td> 
        <td>' . $row['date'] . '</td> 
        <td>' . $row['time'] . '</td> 
        <td>' . $row['address1'] . '</td> 
        <td>' . $row['address2'] . '</td>  
        <td>' . $row['pincode'] . '</td>  
        <td>' . $row['landmark'] . '</td> 
        <td>' . $row['contactnumber'] . '</td>
        <td>' . $row['alternatecontactnumber'] . '</td> 
        <td>' . $row['status'] . '</td>  
        <td>';

        if ($row['status'] == 'Accepted') {
          echo '<a href="javascript:void(0)" class="btn btn-sm btn-primary float-right buy_now" data-img="//www.tutsmake.com/wp-content/uploads/2019/03/c05917807.png" data-amount="' . $row['amount'] . '" data-id="1">Pay Now</a>';
      } elseif ($row['status'] == 'Rejected') {
          echo '<button class="btn btn-sm btn-danger float-right">Rejected</button>';
      } else {
          echo '<button class="btn btn-sm btn-waiting float-right">Waiting</button>';
      }

    echo '</td></tr>';
}
?>

		
	</table>
	</div>
    
  <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>

  $('body').on('click', '.buy_now', function(e){
    var prodimg = $(this).attr("data-img");
    var totalAmount = $(this).attr("data-amount");
    var product_id =  $(this).attr("data-id");
    var options = {
    "key": "rzp_test_zogp4w4jLlCNCx",
    "amount": (totalAmount*100), // 2000 paise = INR 20
    "name": "CarWash",
    "description": "Payment",
 
    "handler": function (response){
          $.ajax({
            url: 'payment-proccess.php',
            type: 'post',
            dataType: 'json',
            data: {
                razorpay_payment_id: response.razorpay_payment_id , totalAmount : totalAmount ,product_id : product_id,
            }, 
            success: function (msg) {

               window.location.href = 'https://www.tutsmake.com/Demos/php/razorpay/success.php';
            }
        });
     
    },

    "theme": {
        "color": "#528FF0"
    }
  };
  var rzp1 = new Razorpay(options);
  rzp1.open();
  e.preventDefault();
  });

</script>

<script src=""></script>
<script>
 
  $('body').on('click', '.buy_now', function(e){
    var prodimg = $(this).attr("data-img");
    var totalAmount = $(this).attr("data-amount");
    var product_id =  $(this).attr("data-id");
    var options = {
    "key": "rzp_test_zogp4w4jLlCNCx", // secret key id
    "amount": (totalAmount*100), // 2000 paise = INR 20
    "name": "CarWash",
    "description": "Payment",
 
    "handler": function (response){
          $.ajax({
            url: 'payment-proccess.php',
            type: 'post',
            dataType: 'json',
            data: {
                razorpay_payment_id: response.razorpay_payment_id , totalAmount : totalAmount ,product_id : product_id,
            }, 
            success: function (msg) {
 
               window.location.href = 'payment-success.php';
            }
        });
      
    },
 
    "theme": {
        "color": "#528FF0"
    }
  };
  var rzp1 = new Razorpay(options);
  rzp1.open();
  e.preventDefault();
  });
 
</script>



  
    
</body>
</html>














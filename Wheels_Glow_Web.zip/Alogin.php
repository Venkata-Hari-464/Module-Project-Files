<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Admin Login Form | wheels Glow</title> 
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <style>
      * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-size: 16px;
    font-family: "Open Sans", Arial, sans-serif;
	
}
      .image{
        height:175px;
        width:220px;
        margin-left:70px;
        margin-top:-169px;
        
      }
      body{
        overflow-y:hidden;
      }
      .wrapper form .signup-link {
    text-align: center;
    margin-top: 20px;
    font-size: 14px;
}
.wrapper form .button input {
    color: #fff;
    font-size: 16px;
    font-weight: 500;
    padding-left: 0px;
    background: #1e6a8f;
    border: 1px solid #1e6a8f;
    cursor: pointer;
}
.wrapper {
    height: 354px;
    width: 100%;
    background: #1e6a8f;
    border-radius: 5px;
    box-shadow: 0px 4px 10px 5px rgba(0,0,0,0.1);
}
.container {
    max-width: 400px;
    padding: 0 20px;
    margin: 170px auto;
}
.wrapper form {
    padding: 52px 29px 29px 27px;
}
.wrapper .title {
  padding-top: 61px;
    height: 71px;
    background: #1e6a8f;
    border-radius: 5px 5px 0 0;
    color: #fff;
    font-size: 30px;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
}
    </style>
  </head>
  <body style="background-image: url('images/loginbgimg.jpg'); background-size:cover;"> 
    <div class="container">
      <!-- <img src="https://i.ibb.co/c2twBLz/titlelogo.png" class="image"/> -->
      <div class="wrapper" style="background-color:#1e6a8f;">
        <div class="title" style="background-color: #1e6a8f;"><span>Login Form</span></div>
        <form action="adminhome.php" method="post">
          <div class="row" >
            <i class="fas fa-user" style="background-color: #1e6a8f;"></i>
            <input type="text" name = "email" placeholder="Enter Your Email" required>
          </div>
          <div class="row">
            <i class="fas fa-lock" style="background-color: #1e6a8f;"></i>
            <input type="password" name = "password" placeholder="Password" required>
          </div>
          
          <div class="row button">
            <input type="submit" value="Login" style="background-color: #1e6a8f;">
          </div>
          <div class="signup-link">Not a member? <a href="Asignup.php" style="color: #67BFFF;">Signup now</a></div>
        </form>
      </div>
    </div>

  </body>
</html>
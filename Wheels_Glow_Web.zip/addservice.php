<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <!-- <link rel="stylesheet" href="navstyle.css"> -->
    <title>Wheelsglow</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/flexslider.css">
<link rel="stylesheet" href="css/jquery.fancybox.css">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/font-icon.css">
<link rel="stylesheet" href="css/animate.min.css">
<link rel="stylesheet" type="text/css" href="css/style4.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" href="http://cdn.bootcss.com/animate.css/3.5.1/animate.min.css">
    <style>
      *{font-size:14px;
        font-family:"Open Sans", Arial, sans-serif;
      }
        body {
            overflow-x: hidden;
            font-family: "Open Sans", Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            
        }
        
        header {
            background-color:#97dcd3;
            color: white;
            padding: 1px;
            text-align: center;
        }

        .hamburger {
            font-size: 20px;
            cursor: pointer;
        }

        .menu-bar {
            display: flex;
            align-items: center;
            font-size: 20px;
            cursor: pointer;
        }

        .menu-items {
            display: none;
            position: absolute;
            background-color: black;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            padding: 10px;
            left: 0;
            top: 40px;
            cursor: pointer;
        }

        .show-menu {
            display: block !important;
        }

        nav {
            background-color:#97dcd3;
            color: white;
            padding: 10px;
            text-align: center;
        }
        
        ul {
            list-style: none;
            padding: 0;
        }
        
        li {
            display: inline;
            margin-right: 20px;
        }
        
        a {
            text-decoration: none;
            color: black;
        }
        
        main {
            padding: 20px;
        }
        
        section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #a8f3e9;
            background-color: white;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        section h2 {
            text-align: center;
            color: black;
        }

        h2 {
            margin-top: 0;
        }

        /* Style for the dropdown menu */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Style for the dropdown button */
        .dropbtn {
            text-decoration: none;
            color: black;
            margin-right: 20px;
        }

        /* Style for the dropdown content */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #3333; /* Background color for dropdown */
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        /* Style for dropdown links */
        .dropdown-content a {
            color: white;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        /* Change color of dropdown links on hover */
        .dropdown-content a:hover {
            background-color: #444;
        }

        /* Display the dropdown content when hovering over the dropdown */
        .dropdown:hover .dropdown-content {
            display: block;
        }
        .img{
            padding-left: 68rem;
        
        }
     .service{
        height: 70px;
         width: 400px;
        background-color: #97dcd3;
        border-radius: 100px;
     }


     form .input-box input {
      font-family:"Open Sans, Arial, sans-serif";
    height: 100%;
    width: 100%;
    outline: none;
    padding: 11px 12px;
    font-size: 14px;
    font-weight: 400;
    color: #333;
    border: 1.5px solid #1e6a8f;
    border-bottom-width: 2.5px;
    border-radius: 6px;
    transition: all 0.3s ease;
}
.input-box input:focus,
.input-box input:valid{
  border-color:#97dcd3;
}
form .policy{
  display: flex;
  align-items: center;
}
form h3{
  color: #707070;
  font-size: 14px;
  font-weight: 500;
  margin-left: 10px;
}
.input-box.button input{
  width: 300px;
    color: #fff;
    letter-spacing: 1px;
    border: none;
    background: #97dcd3;
    cursor: pointer;
    font-size: 14px;
}
.input-box.button input:hover{
  background: #97dcd3;
}
form .text h3{
 color: #333;
 width: 100%;
 text-align: center;
}
form .text h3 a{
  color:#97dcd3;
  text-decoration: none;
}
form .text h3 a:hover{
  text-decoration: underline;
}
    
.box{
  margin-top:10px;
  width:300px;
}
  form{
    height: 200px;
  }
  textarea{
    height: 100%;
  width: 100%;
  outline: none;
  padding: 18px 15px;
  font-size: 14px;
  font-weight: 400;
  color: #333;
  border: 1.5px solid #1e6a8f;
  border-bottom-width: 2.5px;
  border-radius: 6px;
  transition: all 0.3s ease;
    
  }


  @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');

*{
    list-style: none;
    text-decoration: none;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Open Sans", Arial, sans-serif;
}

body{
    background: #f5f6fa;
}

.wrapper .sidebar{
    background:black;
    position: fixed;
    top: 0;
    left: 0;
    width: 225px;
    height: 100%;
    padding: 20px 0;
    transition: all 0.5s ease;
}
.wrapper .sidebar ul li a{
    display: block;
    padding: 13px 30px;
    border-bottom: 1px solid black;
    color: rgb(241, 237, 237);
    font-size: 14px;
    position: relative;
}

.wrapper .sidebar ul li a .icon{
    color: #dee4ec;
    width: 30px;
    display: inline-block;
}
.wrapper .sidebar ul li a:hover,
.wrapper .sidebar ul li a.active{
    color: #0c7db1;

    background:white;
    border-right: 2px solid rgb(5, 68, 104);
}

.wrapper .sidebar ul li a:hover .icon,
.wrapper .sidebar ul li a.active .icon{
    color: #0c7db1;
}

.wrapper .sidebar ul li a:hover:before,
.wrapper .sidebar ul li a.active:before{
    display: block;
}
.wrapper .section{
    width: calc(100% - 225px);
    margin-left: 225px;
    transition: all 0.5s ease;
}

.wrapper .section .top_navbar{
    background:#97dcd3;
    height: 33px;
    display: flex;
    align-items: center;
    padding: 0 30px;

}

.wrapper .section .top_navbar .hamburger a{
    font-size: 28px;
    color: #f4fbff;
}

.wrapper .section .top_navbar .hamburger a:hover{
    color: #a2ecff;
}
body.active .wrapper .sidebar{
    left: -225px;
}

body.active .wrapper .section{
    margin-left: 0;
    width: 100%;
}
.hamburger {
    margin-bottom: -92px;
    font-size: 20px;
    cursor: pointer;
}
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Open Sans", Arial, sans-serif;
}
.alert_box,
.show_button{
  position: absolute;
  top: 50%;
  left: 51%;
  transform: translate(-50% , -50%);
}
.show_button{
  margin-top: 28em;
  height: 55px;
  padding: 0 30px;
  font-size: 20px;
  font-weight: 400;
  cursor: pointer;
  outline: none;
  border: none;
  color: #fff;
  line-height: 55px;
  background: #97dcd3;
  border-radius: 5px;
  transition: all 0.3s ease;
}
.show_button:hover{
  background: #97dcd3;
}
.background{
  position: bottom;
  height: 100%;
  width: 100%;
  top: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.5);
  opacity: 0;
  pointer-events: none;
  transition: all 0.3s ease;
}
.alert_box{
  padding: 30px;
  display: flex;
  background: #fff;
  flex-direction: column;
  align-items: bottom;
  text-align: center;
  max-width: 450px;
  width: 100%;
  border-radius: 5px;
  z-index: 5;
  opacity: 0;
  pointer-events: none;
  transform: translate(-50% , -50%) scale(0.97);
  transition: all 0.3s ease;
}
#check:checked ~ .alert_box{
  opacity: 1;
  pointer-events: auto;
  transform: translate(-50% , -50%) scale(1);
}
#check:checked ~ .background{
  opacity: 1;
  pointer-events: auto;
}
#check{
  display: none;
}
.alert_box .icon{
  height: 100px;
  width: 100px;
  color: #97dcd3;
  border: 3px solid #97dcd3;
  border-radius: 50%;
  line-height: 97px;
  font-size: 50px;
}
.alert_box header{
  font-size: 35px;
  font-weight: 500;
  margin: 10px 0;
}
.alert_box p{
  font-size: 20px;
}
.alert_box .btns{
  margin-top: 20px;
}
.btns label{
  display: inline-flex;
  height: 55px;
  padding: 0 30px;
  font-size: 20px;
  font-weight: 400;
  cursor: pointer;
  line-height: 55px;
  outline: none;
  margin: 0 10px;
  border: none;
  color: #97dcd3;
  border-radius: 5px;
  transition: all 0.3s ease;
}
.btns label:first-child{
  background: #97dcd3;
}
.btns label:first-child:hover{
  background: hidden;
}
.btns label:last-child{
  color:white;
  background: #97dcd3;
}
.btns label:last-child:hover{
  background: hidden;
}




    </style>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="rename_style.css">
     <style>

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;

}
nav .logo a{
font-weight: 500;
font-size: 35px;
color: white;
}
.category-list {
    list-style: none;
    padding: 0;
    text-align: center;
}
.category-item1 {
    background-color: #fff;
    padding: 0px;
    border-radius: 5px;
    box-shadow: 0 0 40px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}
.category-item2 {
    background-color: #fff;
    padding: 10px;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}
.category-icon {
    font-size: 48px;
    margin-bottom: 10px;
}
.category-title {
    font-size: 18px;
    font-weight: bold;
}
a{
    text-decoration: none;
    color:black;
}
.nav-links li a{
text-decoration: none;
color: white;
font-size: 20px;
font-weight: 500;
padding: 10px 4px;
transition: all 0.3s ease;
}
nav {
    position: fixed;
    top: 16px;
    left: 340px;
    width: 100%;
    padding: 11px;
    transition: all 0.4s ease;
    color: white;
    background-color: #1e6a8f;
}
p {
margin-top: 0;
margin-bottom: 0rem;
}
.logo{
font-size:31px;
}
</style>
<style>
  h2 {
    font-size: 36px;
    margin-bottom: -9px;
    color: white;
}
 #header .logo {
  margin-left: -87px;
    float: left;
    font-size: 27px;
    font-weight: 600;
    color: white;
    text-decoration: none;
    text-transform: uppercase;
    letter-spacing: 0px;
    margin-top: -83px;
    background-color: #1e6a8f;
    width: 343px;
    height: 53px;
}
 .intro {
    background-color: #1e6a8f;
    color: white;
}
#header.fixed a {
    color: white;
} #header.fixed {
    background-color: #1e6a8f;
}
.section {
    padding: 22px 0;
}
section {
    margin-bottom: 30px;
    padding: 38px;
    border: 1px solid #1e6a8f;
    background-color: #1e6a8f;
    text-align: center;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}
textarea {
    margin-top: 30px;
    overflow: auto;
    resize: vertical;
}
.navigation a {
    color: #fff;
    font-size: 14px;
    font-weight: 700;
    margin-left: 15px;
    text-transform: uppercase;
}
</style>
</head>
<body style="background-image:url('images/loginbgimg.jpg'); background-size:cover; background-attachment:fixed;">
   
<section class="banner fixed-top" role="banner" id="home">
  <header id="header">
    <div class="header-content clearfix"> <a class="logo" href="index.html">Wheels Glow</a>
      <nav class="navigation" role="navigation">
        <ul class="primary-nav">
		      <li><a href="adminhome.php" style="text-decoration:none;">HOME</a></li>
          <li><a href="addservice.php" style="text-decoration:none;">ADD SERVICES</a></li>
          <li><a href="demo.php" style="text-decoration:none;">ADD DETAILS</a></li> 
          <li><a href="adminorder.php" style="text-decoration:none;">ORDERS</a></li>
          <!-- <li><a href="#teams">Our Team</a></li> -->
		      <!-- <li><a href="#price">Price</a></li> -->
          <!-- <li><a href="#testimonials">Testimonials</a></li> -->
          <!-- <li><a href="#contact">Contact</a></li> -->
        </ul>
</div>
      </nav>
      <!-- <a href="#" class="nav-toggle">Menu<span></span></a> </div> -->
  </header>
</section>
     
<center> 
    <div class="container">
      <!-- <img src="https://i.ibb.co/c2twBLz/titlelogo.png" class="image"/> -->
      <div class="wrapper" style="background-color:#1e6a8f;     width: 382px;height: 610px; margin-top: 75px;">

                           <!-- <main style="width: 500px; margin-left: 400px;"> -->
                            
                           
                                <h2><b style="margin-left:-18px; color:white; font-family:Open Sans, Arial, sans-serif;">ADD SERVICE</b></h2>
                                <BR> 
                              <div class="box">
                                <form action="addservicebackend.php" method="POST">
                                    <div class="input-box">
                                    
                                      <input type="text"  name="service" placeholder=" Service Name : " required>
                                    </div>
                                    <BR>
                                    <div class="input-box">
                                      
                                      <input type="text" name="time" placeholder="Time: " required>
                                      
                                    </div><br>
                                    <div class="input-box">
                                      
                                      <input type="text" name="details" placeholder="More Details:"value="More Details" required>
                                    </div><br>
                                    <div class="input-box">
                                  
                                      <input type="text" name="amount" placeholder="Amount: " required>
                                    </div>
                                    <div class="input-box">
                                        <!-- <h2><li><a href="landscaping.html" style="color:white;font-family:Open Sans, Arial, sans-serif; "> Materials </a></li></h2> -->
                        
                                        <textarea  style="font-family:Open Sans, Arial, sans-serif;"type="text" name="materials" placeholder="Materials.. : "  cols="43" rows="5"></textarea>
                                    </div><br>


                                    <div class="form-group col-mg-3">
                                      <!-- <label for="category">category</lable> -->
                                      <!-- <select name ="category" class="form-control" style=" font-family: Open Sans, Arial, sans-serif;height: 100%;width: 100%;outline: none;padding: 11px 12px;
    font-size: 14px;font-weight: 400;color: #777;border: 1.5px solid #1e6a8f;border-bottom-width: 2.5px;border-radius: 6px;
transition: all 0.3s ease;">
 -->

<?php
                                        $db_host = 'localhost';
                                        $db_user = 'root';
                                        $db_pass = '';
                                        $db_name = 'car';
                                       
                                        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
                                       
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }
// Query to retrieve options from the database
$sql = "SELECT id, servicename FROM category"; // Replace 'categories' with your table name

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    echo '<select name ="category" class="form-control" style=" font-family: Open Sans, Arial, sans-serif;height: 100%;width: 100%;outline: none;padding: 11px 12px;
    font-size: 14px;font-weight: 400;color: #777;border: 1.5px solid #1e6a8f;border-bottom-width: 2.5px;border-radius: 6px;transition: all 0.3s ease;">';
    echo '<option>Select category...</option>';
    while ($row = $result->fetch_assoc()) {
        echo '<option value="' . $row["servicename"] . '">' . $row["servicename"] . '</option>';
    }
    echo '</select>';
} else {
    echo "0 results";
}

$conn->close();
?>

</div><br>
                                    <input type="submit"  value="Submit" style="height:40px; width:100px; background-color:#1e6a8f; color:#ffffff; border-width:0px;  font-family:Open Sans, Arial, sans-serif;border-radius:5px;    margin-top: -76px;">
                                   
                                        </div>
                                      </div>
                                  </form>
                                </div>
                                    </center>         
                                  </main>
        </div> 
</div>
</body>
</html>
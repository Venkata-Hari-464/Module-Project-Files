<?php 
 session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Page </title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="rename_style.css">
    
    <link href="css1/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <style>

        .container {
            max-width: 1280px;
            margin: 20px auto;
            padding: 20px;
            background-color:#eae9e5;

        }
        nav .logo a{
  font-weight: 500;
  font-size: 35px;
  color: white;
}
        .category-list {
            list-style: none;
            padding: 0;
            text-align: center;
        }
        .category-item1 {
    height: 180px;
    background-color: #1e6a8f;
    padding: 2px;
    border-radius: 11px;
    box-shadow: 0 0 40px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    width: 390px;
}
        .category-item2 {
    background-color: #1e6a8f;
    padding: 0px;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    margin-bottom: 4px;
    width: 390px;
    border-width: 0px;
}
        .category-icon {
            font-size: 48px;
            margin-bottom: 10px;
        }
        .category-title {
            font-size: 16px;
            font-weight: bold;
            font-family:"Open Sans", Arial, sans-serif;
            color:black;
            margin-right:50px;
            margin-top:-30px;
            margin-bottom:10px;
        }
        a{
            text-decoration: none;
            color:black;
        }
        .nav-links li a{
  text-decoration: none;
  color: white;
  font-size: 20px;
  font-weight: 500;
  padding: 10px 4px;
  transition: all 0.3s ease;
}
        nav{
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  padding: 14px;
  transition: all 0.4s ease;
  color:white;
  background-color:#1e6a8f;
}
p {
    text-align: justify;
    margin-top: -2px;
    margin-bottom: 0rem;
    font-family: "Open Sans", Arial, sans-serif;
    color: #fff;
    margin-right: 40px;
    font-size: 14px;
}
.logo{
    font-size:31px;
}
dl, ol, ul {
    margin-top: 0;
    margin-bottom: 0rem;
}
.img{
    height:200px; 
    width:300px; 
    margin-top:26px;
}
.box-container{
    margin-left:120px;
}
    </style>
</head>
<body  style="background-color:#EAE9E5;">
<nav>
    <div class="nav-content">
      <div class="logo" style="font-family:Open Sans, Arial, sans-serif; font-size:27px; font-weight:600;">
        WHEELS GLOW
      </div>
      <ul class="nav-links">
        <!-- <li><a href="services.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">HOME</a></li> -->
        <li><a href="services.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">HOME</a></li>
        <li><a href="userviewprofile.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">PROFILE</a></li>
       <li><a href="userorder.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">USER BOOKING </a></li>
       <li><a href="logout.php" style="font-family:Open Sans, Arial, sans-serif; font-size:14px; font-weight:700;">LOGOUT</a></li>
      </ul>
    </div>
  </nav>
  <section class="home">
    
    <div class="container">
        <div style="text-align:center;">
            <h1 style="color: #1e6a8f; font-family:Open Sans, Arial, sans-serif;  color:revert;   font-weight: 700;
    font-size: 20px;" class="mt-5">Services Offering</h1><br>
            <p style="font-size: 14px; margin-left: 350px;color: black;font-family: Open Sans, Arial, sans-serif;">Dive into the portfolio of exceptional services we extend to our discerning clients.</p>
        </div>
        <br><br>
        <div class="box-container d-flex mb-5" style="
            display: flex;
            flex-wrap: wrap;
            flex-direction: row;
            margin: 0 auto;
            justify-content: center;">
        <?php
        
        // Database connection
        $db_host = 'localhost';
        $db_user = 'root';
        $db_pass = '';
        $db_name = 'car';

        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // if (isset($_GET['service'])){
        //   $service = $_GET['service'];
        //   $_SESSION['service'] = $service;
          

       
        // Query to select all images from the table
        $sql = "SELECT * FROM category ";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Retrieve the image data

                $image = $row['image'];
                $servicename = $row['servicename'];
                $informations = $row['informations'];
                
          
                echo '<div class="price-block agile" style="border-radius: 8px;background-color:#1e6a8f;height:340px;width: 360px;margin-left: 20px;margin-bottom: 20px;">';
                    echo '<a href="servicefetch.php?service='.$servicename.'" style="text-decoration:none;">';
                       echo '<li class="category-item1 d-flex flex-column " style="background-color:#1e6a8f; width:355px;">';
                            echo '<span class="category-icon" style="
                            text-align: center;
                        "><img src="./images/' . $image . '" alt=""  style="width:250px; height:150px; margin-top: 15px;"></span>';
                            echo '<div class="ml-5 mt-5 ">';
                                echo '<h2 class="category-title">'.$servicename.'</h2>';
                               echo '<p>'.$informations.'</p>';
                            echo '</div>';
                        echo '</li>';
                   echo '</a>';
                echo '</div>';
            }
        } else {
            echo 'No images found in the table.';
        }
    //   }
        $conn->close();
        ?>

                <!-- <div class="price-block agile" style="margin-right:250px;  border-radius: 8px; background-color:#1e6a8f;">
                    <a href="servicefetch.php?service=under body clean" style="text-decoration:none;">
                        <li class="category-item2 d-flex flex-column" style="width:355px;">
                            <span class="category-icon"><img src="./images./underbodycleaningimg.jpg" class="img" alt=""></span>
                            <div class="ml-5 mt-5">
                                <h2 class="category-title">Underbody Cleaning</h2>
                                <p>Our underbody cleaning service employs powerful techniques, ensuring a meticulous cleanse, eliminating dirt and debris from the often overlooked areas beneath your vehicle.</p>
                            </div>
                        </li>
                    </a>
                </div>
            </div> -->
            <!-- <div class="box-container d-flex flex-row mb-5">
                <div class="price-block agile" style="margin-right:250px;   border-radius: 8px;background-color:#1e6a8f;">
                    <a href="servicefetch.php?service=waterless clean" style="text-decoration:none; margin-right:250px;">
                        <li class="category-item1 d-flex flex-column" style="width:355px;">
                            <span class="category-icon"><img src="./images./waterlesscleaningimg.png" class="img" alt=""></span>
                            <div class="ml-5 mt-5">
                                <h2 class="category-title">Waterless Cleaning</h2>
                                <p>Our eco-friendly waterless cleaning method delivers a pristine shine, without a drop of water, leaving your vehicle spotless and environmentally responsible.</p>
                            </div>

                        </li>
                    </a>
                </div>
                <div class="price-block agile" style="margin-right:250px;  border-radius: 8px; background-color:#1e6a8f;"> 
                    <a href="servicefetch.php?service=car deep clean" style="text-decoration:none;">    
                        <li class="category-item2 d-flex flex-column" style="width:355px;">
                            <span class="category-icon"><img src="./images./cardeepcleaningimg.jpg" class="img" alt=""></span>
                            <div class="ml-5 mt-5">
                                <h2 class="category-title">Car Deep Clean</h2>
                                <p>Our car deep cleaning service goes beyond the surface, meticulously purging contaminants to restore your vehicle's interior to its pristine best.</p>
                            </div>
                        </li>
                    </a>  
                </div>
            </div>  
            <div class="box-container price-block agile" style="width:0px; background-color:#1e6a8f;">
                <a href="servicefetch.php?service=Wash and coat" style="text-decoration:none;">  
                    <li class="category-item1 d-flex flex-column" style="    height: 388px; width:355px;">
                        <span class="category-icon"><img src="./images./washandcoatimg.jpg" class="img" alt=""></span>
                        <div class="ml-5 mt-5 text-center">
                            <h2 class="category-title">Wash and Coat</h2>
                            <p>Our wash and coat service provides a dual benefit, cleansing your vehicle while applying a protective layer, leaving it sparkling and shielded.</p>
                        </div>
                    </li>
                </a>
            </div> -->
    </div>
    </div>
    </section>
    <script>
  let nav = document.querySelector("nav");
    window.onscroll = function() {
      if(document.documentElement.scrollTop > 20){
        nav.classList.add("sticky");
      }else {
        nav.classList.remove("sticky");
      }
    }
  </script>
</body>
</html>
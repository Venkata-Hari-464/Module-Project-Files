<!DOCTYPE html>
<html>
<head>
  <title>PHP Razorpay Payment Gateway Integration </title>
</head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script> 
<style>
  .card-product .img-wrap {
    border-radius: 3px 3px 0 0;
    overflow: hidden;
    position: relative;
    height: 220px;
    text-align: center;
  }
  .card-product .img-wrap img {
    max-height: 100%;
    max-width: 100%;
    object-fit: cover;
  }
  .card-product .info-wrap {
    overflow: hidden;
    padding: 15px;
    border-top: 1px solid #eee;
  }
  .card-product .bottom-wrap {
    padding: 15px;
    border-top: 1px solid #eee;
  }

  .label-rating { margin-right:10px;
    color: #333;
    display: inline-block;
    vertical-align: middle;
  }

  .card-product .price-old {
    color: #999;
  }
  .header-container{
    background-color:#1e6a8f;
    height:75px;
    width:1399px;
    padding-top:25px;
    padding-left:50px;
  }
  body{
    overflow-x:hidden;
  }
  .col-md-4 {
    -ms-flex: 0 0 33.333333%;
    flex: 0 0 33.333333%;
    max-width: 33.333333%;
    top: -40px;
}
.heading{
  font-size:30px;
  font-weight:700;
  top:10px;
  color:#fff;
}
</style>
<body>
<?php
        session_start();
        // Database connection
        $db_host = 'localhost';
        $db_user = 'root';
        $db_pass = '';
        $db_name = 'car';

        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_GET['category'])){
          $service = $_GET['category'];
          $_SESSION['category'] = $service;
          $category = $_SESSION['service'];

       
        // Query to select all images from the table
        $sql = "SELECT * FROM servicename where service='$service' and category='$category'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Retrieve the image data
                $service = $row['service'];
                $category = $row['category'];
                $time = $row['time'];
                $details = $row['details'];
                $amount = $row['amount'];
                $materials = $row['materials'];

 echo' <div class="header-container"><h1 class="heading">WHEELS GLOW</h1></div>';
echo'<div class="container">';
echo'<br><br><br>';
echo'<div class="row" style="justify-content:center;">';


echo '<div class="col-md-4">';
echo'<figure class="card card-product">';
  echo'<div class="img-wrap"><img src="images/paymentscarimg.jpeg" style="width:350px;"></div>';
echo'  <figcaption class="info-wrap">';
echo'      <h4 class="title">'.$category.'</h4>';
echo    ' <p class="desc">'.$service.'</p>';
 echo'     <div class="rating-wrap">';
echo'        <div class="label-rating">132 reviews</div>';
echo'        <div class="label-rating">154 orders </div>';
echo'      </div> ';
echo'  </figcaption>';
 echo' <div class="bottom-wrap">';
  echo'  <a href="javascript:void(0)" class="btn btn-sm btn-primary float-right buy_now" data-img="//www.tutsmake.com/wp-content/uploads/2019/03/c05917807.png" data-amount="'. $row['amount'].'" data-id="1">Book Now</a>'; 
echo'    <div class="price-wrap h5">';
echo'      <span class="price-new">Rs.'.$amount.'</span>' ;
   echo' </div>'; 
 echo' </div>'; 
echo'</figure>';
echo'</div>'; 


echo'</div>'; 

echo'</div>'; 

}
} else {
    echo 'No images found in the table.';
}
}
$conn->close();
?>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>

  $('body').on('click', '.buy_now', function(e){
    var prodimg = $(this).attr("data-img");
    var totalAmount = $(this).attr("data-amount");
    var product_id =  $(this).attr("data-id");
    var options = {
    "key": "rzp_test_zogp4w4jLlCNCx",
    "amount": (totalAmount*100), // 2000 paise = INR 20
    "name": "Wheels Glow",
    "description": "Payment",
 
    "handler": function (response){
          $.ajax({
            url: 'payment-process.php',
            type: 'post',
            dataType: 'json',
            data: {
                razorpay_payment_id: response.razorpay_payment_id , totalAmount : totalAmount ,product_id : product_id,
            }, 
            success: function (msg) {

               window.location.href = 'https://www.tutsmake.com/Demos/php/razorpay/success.php';
            }
        });
     
    },

    "theme": {
        "color": "#528FF0"
    }
  };
  var rzp1 = new Razorpay(options);
  rzp1.open();
  e.preventDefault();
  });

</script>

<script src=""></script>
<script>
 
  $('body').on('click', '.buy_now', function(e){
    var prodimg = $(this).attr("data-img");
    var totalAmount = $(this).attr("data-amount");
    var product_id =  $(this).attr("data-id");
    var options = {
    "key": "rzp_test_zogp4w4jLlCNCx", // secret key id
    "amount": (totalAmount*100), // 2000 paise = INR 20
    "name": "Wheels Glow",
    "description": "Payment",
 
    "handler": function (response){
          $.ajax({
            url: 'payment-process.php',
            type: 'post',
            dataType: 'json',
            data: {
                razorpay_payment_id: response.razorpay_payment_id , totalAmount : totalAmount ,product_id : product_id,
            }, 
            success: function (msg) {
 
               window.location.href = 'payment-success.php';
            }
        });
      
    },
 
    "theme": {
        "color": "#528FF0"
    }
  };
  var rzp1 = new Razorpay(options);
  rzp1.open();
  e.preventDefault();
  });
 
</script>
</body>
</html>